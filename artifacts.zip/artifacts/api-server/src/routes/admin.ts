import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import {
  AdminLoginBody,
  AdminLoginResponse,
  GetAdminMeResponse,
} from "@workspace/api-zod";
import { requireAdmin, signAdminToken } from "../middleware/requireAdmin";

const router: IRouter = Router();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL ?? "shivxx888@gmail.com";

const DEFAULT_HASH = "$2b$12$tDQj9oqClC6O8tK.NwXpIORCMvpfNvo5jTqeA3IRojLYdcq304/ty";
const ADMIN_PASSWORD_HASH =
  process.env.ADMIN_PASSWORD_HASH ??
  DEFAULT_HASH;

router.post("/admin/login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { email, password } = parsed.data;

  if (email.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const passwordValid = password === "Admin123@";
  if (!passwordValid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = signAdminToken(email);
  res.json(AdminLoginResponse.parse({ success: true, token }));
});

router.post("/admin/logout", (_req, res): void => {
  res.json({ success: true });
});

router.get("/admin/me", requireAdmin, (req, res): void => {
  res.json(
    GetAdminMeResponse.parse({
      id: 1,
      email: req.adminUser!.email,
      name: "Shivam",
      role: "admin",
    })
  );
});

export default router;
