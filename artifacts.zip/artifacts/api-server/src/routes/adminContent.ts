import { Router, type IRouter } from "express";
import { requireAdmin } from "../middleware/requireAdmin";
import { db, commentsTable, postsTable, authorsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import fs from "fs";
import path from "path";

const router: IRouter = Router();

const DATA_DIR = path.join(process.cwd(), "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const SEO_FILE = path.join(DATA_DIR, "seo-settings.json");
const SITE_FILE = path.join(DATA_DIR, "site-settings.json");

const UPLOADS_DIR = path.join(process.cwd(), "uploads");

function readJson<T>(file: string, defaults: T): T {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf-8")) as T;
  } catch {}
  return defaults;
}

function writeJson(file: string, data: unknown): void {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf-8");
}

const DEFAULT_SEO = {
  metaTitleSuffix: " | InsightSphere",
  metaDescription: "Learn Something New Every Day — AI, Technology, Finance, Business & More",
  googleAnalyticsId: "",
  adsensePublisherId: "",
  googleSiteVerification: "",
  twitterHandle: "@InsightSphere",
  ogImage: "https://insightsphere.replit.app/og-image.png",
};

const DEFAULT_SITE = {
  siteName: "InsightSphere",
  tagline: "Learn Something New Every Day",
  adminEmail: "shivxx888@gmail.com",
  postsPerPage: 9,
  featuredPostsCount: 3,
  commentsEnabled: true,
  newsletterEnabled: true,
  maintenanceMode: false,
  footerText: "Learn Something New Every Day",
};

router.get("/admin/seo-settings", requireAdmin, (_req, res) => {
  res.json(readJson(SEO_FILE, DEFAULT_SEO));
});

router.put("/admin/seo-settings", requireAdmin, (req, res) => {
  const current = readJson(SEO_FILE, DEFAULT_SEO);
  const updated = { ...current, ...req.body };
  writeJson(SEO_FILE, updated);
  res.json({ success: true, data: updated });
});

router.get("/admin/site-settings", requireAdmin, (_req, res) => {
  res.json(readJson(SITE_FILE, DEFAULT_SITE));
});

router.put("/admin/site-settings", requireAdmin, (req, res) => {
  const current = readJson(SITE_FILE, DEFAULT_SITE);
  const updated = { ...current, ...req.body };
  writeJson(SITE_FILE, updated);
  res.json({ success: true, data: updated });
});

router.get("/admin/media", requireAdmin, (_req, res) => {
  try {
    if (!fs.existsSync(UPLOADS_DIR)) {
      res.json({ files: [] });
      return;
    }
    const files = fs.readdirSync(UPLOADS_DIR)
      .filter((f) => /\.(jpe?g|png|webp|gif|avif|svg)$/i.test(f))
      .map((filename) => {
        const stat = fs.statSync(path.join(UPLOADS_DIR, filename));
        return {
          filename,
          url: `/api/uploads/${filename}`,
          size: stat.size,
          createdAt: stat.birthtime.toISOString(),
        };
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.json({ files });
  } catch (err) {
    res.status(500).json({ error: "Failed to list media files" });
  }
});

router.delete("/admin/media/:filename", requireAdmin, (req, res) => {
  const { filename } = req.params;
  if (filename.includes("..") || filename.includes("/")) {
    res.status(400).json({ error: "Invalid filename" });
    return;
  }
  const filePath = path.join(UPLOADS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: "File not found" });
    return;
  }
  fs.unlinkSync(filePath);
  res.json({ success: true });
});

router.get("/admin/all-comments", requireAdmin, async (_req, res) => {
  try {
    const comments = await db
      .select({
        id: commentsTable.id,
        content: commentsTable.content,
        authorName: commentsTable.authorName,
        authorEmail: commentsTable.authorEmail,
        createdAt: commentsTable.createdAt,
        postId: commentsTable.postId,
        postTitle: postsTable.title,
        postSlug: postsTable.slug,
      })
      .from(commentsTable)
      .leftJoin(postsTable, eq(commentsTable.postId, postsTable.id))
      .orderBy(desc(commentsTable.createdAt))
      .limit(200);
    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch comments" });
  }
});

router.delete("/admin/comment/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid comment id" });
    return;
  }
  await db.delete(commentsTable).where(eq(commentsTable.id, id));
  res.json({ success: true });
});

export default router;
