import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db, postsTable, commentsTable, subscribersTable, categoriesTable } from "@workspace/db";
import {
  GetAnalyticsOverviewResponse,
  GetTopPostsQueryParams,
  GetTopPostsResponse,
  GetCategoryBreakdownResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/analytics/overview", async (_req, res): Promise<void> => {
  const [{ totalPosts }] = await db.select({ totalPosts: sql<number>`count(*)::int` }).from(postsTable);
  const [{ publishedPosts }] = await db
    .select({ publishedPosts: sql<number>`count(*)::int` })
    .from(postsTable)
    .where(eq(postsTable.status, "published"));
  const [{ totalComments }] = await db.select({ totalComments: sql<number>`count(*)::int` }).from(commentsTable);
  const [{ totalSubscribers }] = await db.select({ totalSubscribers: sql<number>`count(*)::int` }).from(subscribersTable);
  const [{ totalViews }] = await db.select({ totalViews: sql<number>`coalesce(sum(view_count), 0)::int` }).from(postsTable);

  const recentPosts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt)).limit(3);
  const recentActivity = recentPosts.map((p) => ({
    type: "post",
    message: `"${p.title}" was ${p.status === "published" ? "published" : "saved as draft"}`,
    time: p.createdAt.toISOString(),
  }));

  res.json(
    GetAnalyticsOverviewResponse.parse({
      totalPosts,
      totalViews,
      totalComments,
      totalSubscribers,
      publishedPosts,
      draftPosts: totalPosts - publishedPosts,
      totalAuthors: 3,
      totalCategories: 10,
      recentActivity,
    })
  );
});

router.get("/analytics/top-posts", async (req, res): Promise<void> => {
  const parsed = GetTopPostsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 10) : 10;
  const posts = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.status, "published"))
    .orderBy(desc(postsTable.viewCount))
    .limit(limit);
  const enriched = await Promise.all(
    posts.map(async (p) => {
      const [cat] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, p.categoryId));
      return {
        postId: p.id,
        title: p.title,
        slug: p.slug,
        viewCount: p.viewCount,
        likeCount: p.likeCount,
        commentCount: p.commentCount,
        category: cat?.name ?? "Uncategorized",
      };
    })
  );
  res.json(GetTopPostsResponse.parse(enriched));
});

router.get("/analytics/category-breakdown", async (_req, res): Promise<void> => {
  const categories = await db.select().from(categoriesTable);
  const breakdown = categories.map((c) => ({
    categoryId: c.id,
    name: c.name,
    slug: c.slug,
    postCount: c.postCount,
    color: c.color,
  }));
  res.json(GetCategoryBreakdownResponse.parse(breakdown));
});

export default router;
