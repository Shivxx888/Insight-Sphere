import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, authorsTable } from "@workspace/db";
import {
  ListAuthorsResponse,
  CreateAuthorBody,
  CreateAuthorResponse,
  GetAuthorParams,
  GetAuthorResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/authors", async (_req, res): Promise<void> => {
  const authors = await db.select().from(authorsTable).orderBy(authorsTable.name);
  const enriched = authors.map((a) => ({
    ...a,
    social: (a.social as Record<string, string | null>) || {},
  }));
  res.json(ListAuthorsResponse.parse(enriched));
});

router.post("/authors", async (req, res): Promise<void> => {
  const parsed = CreateAuthorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [author] = await db.insert(authorsTable).values(parsed.data).returning();
  res.status(201).json(CreateAuthorResponse.parse({ ...author, social: (author.social as Record<string, string | null>) || {} }));
});

router.get("/authors/:id", async (req, res): Promise<void> => {
  const params = GetAuthorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [author] = await db.select().from(authorsTable).where(eq(authorsTable.id, params.data.id));
  if (!author) {
    res.status(404).json({ error: "Author not found" });
    return;
  }
  res.json(GetAuthorResponse.parse({ ...author, social: (author.social as Record<string, string | null>) || {} }));
});

export default router;
