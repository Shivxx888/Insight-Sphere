import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, commentsTable, postsTable } from "@workspace/db";
import {
  ListCommentsParams,
  ListCommentsResponse,
  CreateCommentParams,
  CreateCommentBody,
  CreateCommentResponse,
  ListRecentCommentsQueryParams,
  ListRecentCommentsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/posts/:slug/comments", async (req, res): Promise<void> => {
  const params = ListCommentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [post] = await db.select().from(postsTable).where(eq(postsTable.slug, params.data.slug));
  if (!post) {
    res.json([]);
    return;
  }
  const comments = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.postId, post.id))
    .orderBy(desc(commentsTable.createdAt));
  const enriched = comments.map((c) => ({
    ...c,
    createdAt: c.createdAt.toISOString(),
    postSlug: params.data.slug,
    postTitle: post.title,
    avatar: null,
  }));
  res.json(ListCommentsResponse.parse(enriched));
});

router.post("/posts/:slug/comments", async (req, res): Promise<void> => {
  const params = CreateCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateCommentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [post] = await db.select().from(postsTable).where(eq(postsTable.slug, params.data.slug));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  const [comment] = await db
    .insert(commentsTable)
    .values({ ...parsed.data, postId: post.id })
    .returning();
  res.status(201).json(
    CreateCommentResponse.parse({
      ...comment,
      createdAt: comment.createdAt.toISOString(),
      postSlug: params.data.slug,
      postTitle: post.title,
      avatar: null,
    })
  );
});

router.get("/comments/recent", async (req, res): Promise<void> => {
  const parsed = ListRecentCommentsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 5) : 5;
  const comments = await db
    .select()
    .from(commentsTable)
    .orderBy(desc(commentsTable.createdAt))
    .limit(limit);

  const enriched = await Promise.all(
    comments.map(async (c) => {
      const [post] = await db.select().from(postsTable).where(eq(postsTable.id, c.postId));
      return {
        ...c,
        createdAt: c.createdAt.toISOString(),
        postSlug: post?.slug ?? "",
        postTitle: post?.title ?? "",
        avatar: null,
      };
    })
  );
  res.json(ListRecentCommentsResponse.parse(enriched));
});

export default router;
