import { Router, type IRouter } from "express";
import { db, postsTable, authorsTable, categoriesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

router.get("/feed.xml", async (req, res) => {
  try {
    const posts = await db
      .select({
        title: postsTable.title,
        slug: postsTable.slug,
        excerpt: postsTable.excerpt,
        content: postsTable.content,
        coverImage: postsTable.coverImage,
        publishedAt: postsTable.publishedAt,
        updatedAt: postsTable.updatedAt,
        tags: postsTable.tags,
        authorName: authorsTable.name,
        authorEmail: authorsTable.email,
        categoryName: categoriesTable.name,
      })
      .from(postsTable)
      .leftJoin(authorsTable, eq(postsTable.authorId, authorsTable.id))
      .leftJoin(categoriesTable, eq(postsTable.categoryId, categoriesTable.id))
      .where(eq(postsTable.status, "published"))
      .orderBy(desc(postsTable.publishedAt))
      .limit(50);

    const host = req.get("x-forwarded-host") || req.get("host") || "insightsphere.replit.app";
    const protocol = req.get("x-forwarded-proto") || req.protocol || "https";
    const domain = `${protocol}://${host}`;
    const buildDate = new Date().toUTCString();

    const items = posts.map((post) => {
      const link = `${domain}/blog/${post.slug}`;
      const pubDate = post.publishedAt ? new Date(post.publishedAt).toUTCString() : buildDate;
      const tags = Array.isArray(post.tags) ? (post.tags as string[]) : [];
      const categories = [post.categoryName, ...tags].filter(Boolean);
      const description = escapeXml(post.excerpt);
      const content = escapeXml(
        post.content.replace(/#{1,6}\s/g, "").replace(/\*\*(.+?)\*\*/g, "$1").replace(/\*(.+?)\*/g, "$1").replace(/`(.+?)`/g, "$1")
      );

      return `    <item>
      <title>${escapeXml(post.title)}</title>
      <link>${link}</link>
      <guid isPermaLink="true">${link}</guid>
      <description>${description}</description>
      <content:encoded><![CDATA[${content}]]></content:encoded>
      <pubDate>${pubDate}</pubDate>
      <author>${escapeXml(post.authorEmail ?? "shivxx888@gmail.com")} (${escapeXml(post.authorName ?? "Shivam")})</author>
      ${categories.map((c) => `<category>${escapeXml(c ?? "")}</category>`).join("\n      ")}
      ${post.coverImage ? `<enclosure url="${escapeXml(post.coverImage)}" type="image/jpeg" />` : ""}
      <media:thumbnail url="${escapeXml(post.coverImage ?? `https://picsum.photos/seed/${post.slug}/600/400`)}" />
    </item>`;
    });

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:media="http://search.yahoo.com/mrss/"
  xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>InsightSphere — Learn Something New Every Day</title>
    <link>${domain}</link>
    <description>Your premier destination for deep insights on AI, technology, finance, digital marketing, cybersecurity, and online business.</description>
    <language>en-us</language>
    <managingEditor>shivxx888@gmail.com (Shivam)</managingEditor>
    <webMaster>shivxx888@gmail.com (Shivam)</webMaster>
    <lastBuildDate>${buildDate}</lastBuildDate>
    <ttl>60</ttl>
    <image>
      <url>${domain}/favicon.svg</url>
      <title>InsightSphere</title>
      <link>${domain}</link>
    </image>
    <atom:link href="${domain}/api/feed.xml" rel="self" type="application/rss+xml" />
${items.join("\n")}
  </channel>
</rss>`;

    res.setHeader("Content-Type", "application/rss+xml; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=3600, s-maxage=3600");
    res.send(xml);
  } catch (err) {
    req.log.error(err, "Failed to generate RSS feed");
    res.status(500).send("Failed to generate feed");
  }
});

export default router;
