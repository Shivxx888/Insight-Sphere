import { Router, type IRouter } from "express";
import healthRouter from "./health";
import postsRouter from "./posts";
import categoriesRouter from "./categories";
import authorsRouter from "./authors";
import commentsRouter from "./comments";
import newsletterRouter from "./newsletter";
import analyticsRouter from "./analytics";
import adminRouter from "./admin";
import adminContentRouter from "./adminContent";
import searchRouter from "./search";
import contactRouter from "./contact";
import sitemapRouter from "./sitemap";
import feedRouter from "./feed";
import uploadRouter from "./upload";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sitemapRouter);
router.use(feedRouter);
router.use(uploadRouter);
router.use(postsRouter);
router.use(categoriesRouter);
router.use(authorsRouter);
router.use(commentsRouter);
router.use(newsletterRouter);
router.use(analyticsRouter);
router.use(adminRouter);
router.use(adminContentRouter);
router.use(searchRouter);
router.use(contactRouter);

export default router;
