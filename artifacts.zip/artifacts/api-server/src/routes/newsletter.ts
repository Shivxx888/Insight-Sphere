import { Router, type IRouter } from "express";
import { db, subscribersTable } from "@workspace/db";
import {
  SubscribeNewsletterBody,
  SubscribeNewsletterResponse,
  ListSubscribersResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/newsletter/subscribe", async (req, res): Promise<void> => {
  const parsed = SubscribeNewsletterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await db.insert(subscribersTable).values(parsed.data).onConflictDoNothing();
    res.json(SubscribeNewsletterResponse.parse({ success: true, message: "Successfully subscribed!" }));
  } catch {
    res.json(SubscribeNewsletterResponse.parse({ success: false, message: "Already subscribed." }));
  }
});

router.get("/newsletter/subscribers", async (_req, res): Promise<void> => {
  const subscribers = await db.select().from(subscribersTable).orderBy(subscribersTable.subscribedAt);
  const enriched = subscribers.map((s) => ({
    ...s,
    subscribedAt: s.subscribedAt.toISOString(),
  }));
  res.json(ListSubscribersResponse.parse(enriched));
});

export default router;
