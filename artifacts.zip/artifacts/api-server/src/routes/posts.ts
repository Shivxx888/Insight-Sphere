import { Router, type IRouter } from "express";
import { eq, desc, and, ilike, inArray, sql } from "drizzle-orm";
import { db, postsTable, categoriesTable, authorsTable, commentsTable } from "@workspace/db";
import {
  ListPostsQueryParams,
  ListPostsResponse,
  CreatePostBody,
  CreatePostResponse,
  ListFeaturedPostsResponse,
  ListTrendingPostsQueryParams,
  ListTrendingPostsResponse,
  ListLatestPostsQueryParams,
  ListLatestPostsResponse,
  GetPostParams,
  GetPostResponse,
  UpdatePostParams,
  UpdatePostBody,
  UpdatePostResponse,
  DeletePostParams,
  ListRelatedPostsParams,
  ListRelatedPostsResponse,
  LikePostParams,
  LikePostResponse,
  BookmarkPostParams,
  BookmarkPostResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function enrichPost(post: typeof postsTable.$inferSelect) {
  const [author] = await db.select().from(authorsTable).where(eq(authorsTable.id, post.authorId));
  const [category] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, post.categoryId));
  return {
    ...post,
    publishedAt: post.publishedAt ? post.publishedAt.toISOString() : null,
    author: author
      ? {
          id: author.id,
          name: author.name,
          email: author.email,
          bio: author.bio,
          avatar: author.avatar,
          role: author.role,
          postCount: author.postCount,
          social: (author.social as Record<string, string | null>) || {},
        }
      : { id: 0, name: "Unknown", email: "", bio: "", avatar: "", role: "Author", postCount: 0, social: {} },
    category: category
      ? {
          id: category.id,
          name: category.name,
          slug: category.slug,
          description: category.description,
          color: category.color,
          icon: category.icon,
          postCount: category.postCount,
        }
      : { id: 0, name: "Uncategorized", slug: "uncategorized", description: "", color: "#3B82F6", icon: "Tag", postCount: 0 },
  };
}

router.get("/posts", async (req, res): Promise<void> => {
  const parsed = ListPostsQueryParams.safeParse(req.query);
  const page = parsed.success ? (parsed.data.page ?? 1) : 1;
  const limit = parsed.success ? (parsed.data.limit ?? 12) : 12;
  const categorySlug = parsed.success ? parsed.data.category : undefined;
  const offset = (page - 1) * limit;

  let categoryId: number | undefined;
  if (categorySlug) {
    const [cat] = await db.select().from(categoriesTable).where(eq(categoriesTable.slug, categorySlug));
    categoryId = cat?.id;
  }

  const conditions = [eq(postsTable.status, "published")];
  if (categoryId !== undefined) conditions.push(eq(postsTable.categoryId, categoryId));

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(postsTable)
    .where(and(...conditions));

  const posts = await db
    .select()
    .from(postsTable)
    .where(and(...conditions))
    .orderBy(desc(postsTable.publishedAt))
    .limit(limit)
    .offset(offset);

  const enriched = await Promise.all(posts.map(enrichPost));
  res.json(
    ListPostsResponse.parse({
      posts: enriched,
      total: count,
      page,
      limit,
      totalPages: Math.ceil(count / limit),
    })
  );
});

router.post("/posts", async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = parsed.data;
  const publishedAt = data.status === "published" ? new Date() : null;
  const [post] = await db
    .insert(postsTable)
    .values({
      ...data,
      publishedAt,
      readingTime: Math.ceil((data.content?.split(" ").length || 0) / 200) || 5,
    })
    .returning();

  if (data.status === "published") {
    await db
      .update(authorsTable)
      .set({ postCount: sql`${authorsTable.postCount} + 1` })
      .where(eq(authorsTable.id, data.authorId));
    await db
      .update(categoriesTable)
      .set({ postCount: sql`${categoriesTable.postCount} + 1` })
      .where(eq(categoriesTable.id, data.categoryId));
  }

  const enriched = await enrichPost(post);
  res.status(201).json(CreatePostResponse.parse(enriched));
});

router.get("/posts/featured", async (_req, res): Promise<void> => {
  const posts = await db
    .select()
    .from(postsTable)
    .where(and(eq(postsTable.status, "published"), eq(postsTable.featured, true)))
    .orderBy(desc(postsTable.publishedAt))
    .limit(3);
  const enriched = await Promise.all(posts.map(enrichPost));
  res.json(ListFeaturedPostsResponse.parse(enriched));
});

router.get("/posts/trending", async (req, res): Promise<void> => {
  const parsed = ListTrendingPostsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 5) : 5;
  const posts = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.status, "published"))
    .orderBy(desc(postsTable.viewCount))
    .limit(limit);
  const enriched = await Promise.all(posts.map(enrichPost));
  res.json(ListTrendingPostsResponse.parse(enriched));
});

router.get("/posts/latest", async (req, res): Promise<void> => {
  const parsed = ListLatestPostsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 6) : 6;
  const posts = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.status, "published"))
    .orderBy(desc(postsTable.publishedAt))
    .limit(limit);
  const enriched = await Promise.all(posts.map(enrichPost));
  res.json(ListLatestPostsResponse.parse(enriched));
});

router.get("/posts/:slug/related", async (req, res): Promise<void> => {
  const params = ListRelatedPostsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [current] = await db.select().from(postsTable).where(eq(postsTable.slug, params.data.slug));
  if (!current) {
    res.json([]);
    return;
  }
  const related = await db
    .select()
    .from(postsTable)
    .where(
      and(
        eq(postsTable.status, "published"),
        eq(postsTable.categoryId, current.categoryId),
        sql`${postsTable.id} != ${current.id}`
      )
    )
    .orderBy(desc(postsTable.publishedAt))
    .limit(4);
  const enriched = await Promise.all(related.map(enrichPost));
  res.json(ListRelatedPostsResponse.parse(enriched));
});

router.get("/posts/:slug/comments", async (req, res): Promise<void> => {
  res.json([]);
});

router.post("/posts/:slug/like", async (req, res): Promise<void> => {
  const params = LikePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [updated] = await db
    .update(postsTable)
    .set({ likeCount: sql`${postsTable.likeCount} + 1` })
    .where(eq(postsTable.slug, params.data.slug))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  res.json(LikePostResponse.parse({ likeCount: updated.likeCount, liked: true }));
});

router.post("/posts/:slug/bookmark", async (req, res): Promise<void> => {
  const params = BookmarkPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  res.json(BookmarkPostResponse.parse({ bookmarked: true }));
});

router.get("/posts/:slug", async (req, res): Promise<void> => {
  const params = GetPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [post] = await db.select().from(postsTable).where(eq(postsTable.slug, params.data.slug));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  await db
    .update(postsTable)
    .set({ viewCount: sql`${postsTable.viewCount} + 1` })
    .where(eq(postsTable.id, post.id));
  post.viewCount += 1;
  const enriched = await enrichPost(post);
  res.json(GetPostResponse.parse(enriched));
});

router.patch("/posts/:slug", async (req, res): Promise<void> => {
  const params = UpdatePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.status === "published") {
    updateData.publishedAt = new Date();
  }
  const [post] = await db
    .update(postsTable)
    .set(updateData as unknown as Partial<typeof postsTable.$inferInsert>)
    .where(eq(postsTable.slug, params.data.slug))
    .returning();
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  const enriched = await enrichPost(post);
  res.json(UpdatePostResponse.parse(enriched));
});

router.delete("/posts/:slug", async (req, res): Promise<void> => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(postsTable)
    .where(eq(postsTable.slug, params.data.slug))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
