import { Router, type IRouter } from "express";
import { eq, desc, ilike, and } from "drizzle-orm";
import { db, postsTable, categoriesTable, authorsTable } from "@workspace/db";
import { SearchPostsQueryParams, SearchPostsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/search", async (req, res): Promise<void> => {
  const parsed = SearchPostsQueryParams.safeParse(req.query);
  if (!parsed.success || !parsed.data.q) {
    res.json([]);
    return;
  }
  const { q, limit = 10 } = parsed.data;
  const posts = await db
    .select()
    .from(postsTable)
    .where(
      and(
        eq(postsTable.status, "published"),
        ilike(postsTable.title, `%${q}%`)
      )
    )
    .orderBy(desc(postsTable.publishedAt))
    .limit(limit);

  const enriched = await Promise.all(
    posts.map(async (post) => {
      const [author] = await db.select().from(authorsTable).where(eq(authorsTable.id, post.authorId));
      const [category] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, post.categoryId));
      return {
        ...post,
        publishedAt: post.publishedAt ? post.publishedAt.toISOString() : null,
        author: author
          ? { id: author.id, name: author.name, email: author.email, bio: author.bio, avatar: author.avatar, role: author.role, postCount: author.postCount, social: (author.social as Record<string, string | null>) || {} }
          : { id: 0, name: "Unknown", email: "", bio: "", avatar: "", role: "Author", postCount: 0, social: {} },
        category: category
          ? { id: category.id, name: category.name, slug: category.slug, description: category.description, color: category.color, icon: category.icon, postCount: category.postCount }
          : { id: 0, name: "Uncategorized", slug: "uncategorized", description: "", color: "#3B82F6", icon: "Tag", postCount: 0 },
      };
    })
  );
  res.json(SearchPostsResponse.parse(enriched));
});

export default router;
