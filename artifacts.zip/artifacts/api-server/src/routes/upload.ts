import { Router, type IRouter } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import sharp from "sharp";

const router: IRouter = Router();

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif", "image/avif"];
    cb(null, allowed.includes(file.mimetype));
  },
});

router.post("/upload", upload.single("image"), async (req, res) => {
  if (!req.file) {
    res.status(400).json({ error: "No file uploaded or invalid file type. Allowed: JPEG, PNG, WebP, GIF, AVIF." });
    return;
  }

  try {
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).slice(2, 8);
    const filename = `${timestamp}-${randomId}.webp`;
    const outputPath = path.join(uploadsDir, filename);

    await sharp(req.file.buffer)
      .resize(1200, 800, { fit: "inside", withoutEnlargement: true })
      .webp({ quality: 82, effort: 4 })
      .toFile(outputPath);

    const host = req.get("x-forwarded-host") || req.get("host") || "localhost";
    const protocol = req.get("x-forwarded-proto") || req.protocol || "https";
    const url = `${protocol}://${host}/api/uploads/${filename}`;

    const stat = fs.statSync(outputPath);
    const originalKB = Math.round(req.file.size / 1024);
    const outputKB = Math.round(stat.size / 1024);

    req.log.info({ originalKB, outputKB, filename }, "Image uploaded and compressed");
    res.json({ url, filename, originalKB, outputKB });
  } catch (err) {
    req.log.error(err, "Image processing failed");
    res.status(500).json({ error: "Image processing failed. Please try again." });
  }
});

export default router;
