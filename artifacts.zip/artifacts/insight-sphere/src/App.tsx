import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { GoogleAnalytics } from "@/components/GoogleAnalytics";

import HomePage from "@/pages/HomePage";
import BlogPage from "@/pages/BlogPage";
import ArticlePage from "@/pages/ArticlePage";
import CategoriesPage from "@/pages/CategoriesPage";
import CategoryPage from "@/pages/CategoryPage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import { PrivacyPage, TermsPage, DisclaimerPage, CookiePolicyPage } from "@/pages/StaticPages";
import NotFound from "@/pages/not-found";

const AdminLogin = lazy(() => import("@/pages/admin/AdminLogin"));
const AdminDashboard = lazy(() => import("@/pages/admin/AdminDashboard"));
const AdminPosts = lazy(() => import("@/pages/admin/AdminPosts"));
const PostEditor = lazy(() => import("@/pages/admin/PostEditor"));
const AdminCategories = lazy(() => import("@/pages/admin/AdminCategories"));
const AdminNewsletter = lazy(() => import("@/pages/admin/AdminNewsletter"));
const AdminComments = lazy(() => import("@/pages/admin/AdminComments"));
const AdminMediaLibrary = lazy(() => import("@/pages/admin/AdminMediaLibrary"));
const AdminSEOSettings = lazy(() => import("@/pages/admin/AdminSEOSettings"));
const AdminSiteSettings = lazy(() => import("@/pages/admin/AdminSiteSettings"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 2,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function AdminFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-muted-foreground">Loading...</p>
      </div>
    </div>
  );
}

function A({ children }: { children: React.ReactNode }) {
  return <Suspense fallback={<AdminFallback />}>{children}</Suspense>;
}

function Router() {
  return (
    <Switch>
      {/* Public pages */}
      <Route path="/" component={HomePage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/blog/:slug" component={ArticlePage} />
      <Route path="/categories" component={CategoriesPage} />
      <Route path="/categories/:slug" component={CategoryPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/disclaimer" component={DisclaimerPage} />
      <Route path="/cookie-policy" component={CookiePolicyPage} />

      {/* Admin auth */}
      <Route path="/admin/login">
        <A><AdminLogin /></A>
      </Route>

      {/* Admin pages — /admin redirects to /admin/dashboard */}
      <Route path="/admin">
        <A><AdminDashboard /></A>
      </Route>
      <Route path="/admin/dashboard">
        <A><AdminDashboard /></A>
      </Route>
      <Route path="/admin/posts">
        <A><AdminPosts /></A>
      </Route>
      <Route path="/admin/posts/new">
        <A><PostEditor /></A>
      </Route>
      <Route path="/admin/posts/:slug/edit">
        <A><PostEditor /></A>
      </Route>
      <Route path="/admin/categories">
        <A><AdminCategories /></A>
      </Route>
      <Route path="/admin/newsletter">
        <A><AdminNewsletter /></A>
      </Route>
      <Route path="/admin/comments">
        <A><AdminComments /></A>
      </Route>
      <Route path="/admin/media">
        <A><AdminMediaLibrary /></A>
      </Route>
      <Route path="/admin/seo">
        <A><AdminSEOSettings /></A>
      </Route>
      <Route path="/admin/settings">
        <A><AdminSiteSettings /></A>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <GoogleAnalytics />
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
