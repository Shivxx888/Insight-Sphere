import { useEffect, useRef } from "react";

type AdFormat = "auto" | "rectangle" | "horizontal" | "vertical" | "in-article";

interface AdSlotProps {
  slot?: string;
  format?: AdFormat;
  className?: string;
  style?: React.CSSProperties;
}

declare global {
  interface Window {
    adsbygoogle: unknown[];
  }
}

const PUBLISHER_ID = (import.meta.env.VITE_ADSENSE_PUBLISHER_ID as string | undefined) ?? "ca-pub-XXXXXXXXXXXXXXXX";

export function AdSlot({ slot = "auto", format = "auto", className = "", style }: AdSlotProps) {
  const initialized = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialized.current || !containerRef.current) return;
    initialized.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
    }
  }, []);

  if (PUBLISHER_ID === "ca-pub-XXXXXXXXXXXXXXXX") {
    return (
      <div
        ref={containerRef}
        className={`ad-slot-placeholder flex items-center justify-center bg-muted/40 border border-dashed border-border rounded-lg text-xs text-muted-foreground ${className}`}
        style={{ minHeight: style?.minHeight ?? 90, ...style }}
        aria-label="Ad slot placeholder"
      >
        <span className="opacity-50">Advertisement</span>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`ad-slot-container overflow-hidden text-center ${className}`}
      style={style}
      aria-label="Advertisement"
    >
      <ins
        className="adsbygoogle"
        style={{ display: "block", ...style }}
        data-ad-client={PUBLISHER_ID}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
    </div>
  );
}

export function AdSlotBanner({ className = "" }: { className?: string }) {
  return (
    <div className={`my-6 ${className}`}>
      <AdSlot format="horizontal" slot="1234567890" style={{ minHeight: 90 }} />
    </div>
  );
}

export function AdSlotRectangle({ className = "" }: { className?: string }) {
  return (
    <div className={`my-4 ${className}`}>
      <AdSlot format="rectangle" slot="0987654321" style={{ minHeight: 280 }} />
    </div>
  );
}

export function AdSlotInArticle({ className = "" }: { className?: string }) {
  return (
    <div className={`my-8 ${className}`}>
      <AdSlot format="in-article" slot="1122334455" />
    </div>
  );
}
