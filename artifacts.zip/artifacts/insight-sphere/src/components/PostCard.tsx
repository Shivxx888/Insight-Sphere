import { Link } from "wouter";
import { Clock, Eye, Heart, MessageCircle, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Post } from "@workspace/api-client-react";

interface PostCardProps {
  post: Post;
  variant?: "default" | "featured" | "compact" | "horizontal";
}

function formatDate(dateStr: string | null) {
  if (!dateStr) return "";
  return new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function AuthorAvatar({ name, avatar, className }: { name: string; avatar?: string | null; className?: string }) {
  if (avatar && avatar.startsWith("http")) {
    return (
      <img
        src={avatar}
        alt={name}
        className={`object-cover ${className ?? ""}`}
        loading="lazy"
        decoding="async"
        width={32}
        height={32}
      />
    );
  }
  return (
    <div
      className={`bg-gradient-to-br from-primary via-primary/80 to-primary/60 flex items-center justify-center text-white font-bold text-xs ${className ?? ""}`}
    >
      {name?.[0]?.toUpperCase() ?? "S"}
    </div>
  );
}

export function PostCard({ post, variant = "default" }: PostCardProps) {
  if (variant === "horizontal") {
    return (
      <Link href={`/blog/${post.slug}`}>
        <article
          className="flex gap-4 group cursor-pointer"
          data-testid={`card-post-${post.id}`}
        >
          <div className="shrink-0 w-24 h-24 rounded-lg overflow-hidden bg-muted">
            <img
              src={post.coverImage || `https://picsum.photos/seed/${post.id}/200/200`}
              alt={post.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
              decoding="async"
              width={96}
              height={96}
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-medium text-primary">{post.category.name}</span>
            </div>
            <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors leading-snug">
              {post.title}
            </h3>
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readingTime}m</span>
              <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{post.viewCount}</span>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  if (variant === "compact") {
    return (
      <Link href={`/blog/${post.slug}`}>
        <article
          className="flex items-start gap-3 group cursor-pointer"
          data-testid={`card-post-${post.id}`}
        >
          <div className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0" />
          <div>
            <h3 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors line-clamp-2">
              {post.title}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">{formatDate(post.publishedAt)}</p>
          </div>
        </article>
      </Link>
    );
  }

  if (variant === "featured") {
    return (
      <Link href={`/blog/${post.slug}`}>
        <article
          className="relative group cursor-pointer overflow-hidden rounded-2xl h-[480px]"
          data-testid={`card-post-featured-${post.id}`}
        >
          <img
            src={post.coverImage || `https://picsum.photos/seed/${post.id}/800/600`}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="eager"
            fetchPriority="high"
            decoding="async"
            width={800}
            height={480}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-3">
              <Badge className="text-xs" style={{ backgroundColor: post.category.color, color: "#fff" }}>
                {post.category.name}
              </Badge>
              <span className="text-white/70 text-xs">{formatDate(post.publishedAt)}</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight group-hover:text-primary/90 transition-colors line-clamp-3">
              {post.title}
            </h2>
            <p className="text-white/80 text-sm mt-2 line-clamp-2 hidden md:block">{post.excerpt}</p>
            <div className="flex items-center gap-4 mt-4">
              <div className="flex items-center gap-2">
                <AuthorAvatar
                  name={post.author.name}
                  avatar={post.author.avatar}
                  className="w-7 h-7 rounded-full border-2 border-white/50"
                />
                <span className="text-white/90 text-sm font-medium">{post.author.name}</span>
              </div>
              <span className="text-white/60 text-xs flex items-center gap-1">
                <Clock className="w-3 h-3" />{post.readingTime} min read
              </span>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  return (
    <Link href={`/blog/${post.slug}`}>
      <article
        className="group cursor-pointer bg-card border border-border rounded-2xl overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all duration-300"
        data-testid={`card-post-${post.id}`}
      >
        <div className="relative overflow-hidden aspect-video bg-muted">
          <img
            src={post.coverImage || `https://picsum.photos/seed/${post.id}/600/400`}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
            decoding="async"
            width={600}
            height={338}
          />
          <div className="absolute top-3 left-3">
            <Badge className="text-xs" style={{ backgroundColor: post.category.color, color: "#fff" }}>
              {post.category.name}
            </Badge>
          </div>
        </div>
        <div className="p-5">
          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{formatDate(post.publishedAt)}</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readingTime} min</span>
          </div>
          <h3 className="text-base font-bold text-foreground group-hover:text-primary transition-colors line-clamp-2 leading-snug mb-2">
            {post.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{post.excerpt}</p>
          <div className="flex items-center justify-between pt-3 border-t border-border">
            <div className="flex items-center gap-2">
              <AuthorAvatar
                name={post.author.name}
                avatar={post.author.avatar}
                className="w-6 h-6 rounded-full"
              />
              <span className="text-xs text-muted-foreground font-medium">{post.author.name}</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{post.viewCount}</span>
              <span className="flex items-center gap-1"><Heart className="w-3 h-3" />{post.likeCount}</span>
              <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" />{post.commentCount}</span>
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
}
