import { motion } from "framer-motion";
import { Target, Eye, Award, Users, Mail, Twitter, Linkedin, Globe, BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import { useEffect } from "react";

const STATS = [
  { label: "Articles Published", value: "50+" },
  { label: "Monthly Readers", value: "10K+" },
  { label: "Topics Covered", value: "10" },
  { label: "Years of Experience", value: "5+" },
];

const VALUES = [
  {
    icon: <Target className="w-6 h-6 text-primary" />,
    title: "Our Mission",
    desc: "To make complex ideas in AI, technology, and business accessible, actionable, and genuinely useful to every curious professional.",
  },
  {
    icon: <Eye className="w-6 h-6 text-primary" />,
    title: "Our Vision",
    desc: "A world where lifelong learning is effortless — where anyone can stay ahead of the curve in an era of relentless change.",
  },
  {
    icon: <Award className="w-6 h-6 text-primary" />,
    title: "Our Standards",
    desc: "Every article is thoroughly researched and written with care for accuracy, depth, and practical value. No filler, no fluff.",
  },
  {
    icon: <Users className="w-6 h-6 text-primary" />,
    title: "Our Community",
    desc: "We're building a community of curious, ambitious readers who believe knowledge — properly applied — is the ultimate competitive advantage.",
  },
];

const TOPICS = [
  "Artificial Intelligence", "Technology", "Finance", "Make Money Online",
  "Business", "Education", "Digital Marketing", "Cybersecurity", "Mobile Apps", "How-To Guides",
];

export default function AboutPage() {
  useEffect(() => {
    document.title = "About | InsightSphere — Learn Something New Every Day";
  }, []);

  return (
    <Layout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16" data-testid="page-about">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

          {/* Hero */}
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="outline">Est. 2024</Badge>
            <h1 className="text-5xl font-bold text-foreground mb-4 font-serif">About InsightSphere</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              <em>Learn Something New Every Day</em> — your premier destination for deep dives into AI, technology, finance, and modern business.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
            {STATS.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center bg-card border border-border rounded-2xl p-6"
              >
                <p className="text-3xl font-black text-primary mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          {/* Values */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            {VALUES.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-2xl p-6"
                data-testid={`about-card-${i}`}
              >
                <div className="w-11 h-11 bg-primary/10 rounded-xl flex items-center justify-center mb-4">{item.icon}</div>
                <h3 className="text-lg font-bold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* Author Profile */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Meet the Author</h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-card border border-border rounded-3xl p-8 md:p-10 flex flex-col md:flex-row items-center md:items-start gap-8"
              data-testid="author-card-shivam"
            >
              {/* Avatar */}
              <div className="shrink-0">
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary via-primary/80 to-primary/60 flex items-center justify-center shadow-xl ring-4 ring-primary/20">
                  <span className="text-5xl font-black text-white">S</span>
                </div>
              </div>
              {/* Info */}
              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-col md:flex-row items-center md:items-start gap-3 mb-3">
                  <h3 className="text-2xl font-bold text-foreground">Shivam</h3>
                  <Badge className="bg-primary/10 text-primary border-primary/20">Founder & Editor</Badge>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  I'm the founder and editor of InsightSphere, a blog dedicated to making complex ideas in AI, technology, personal finance, and digital entrepreneurship accessible to everyone.
                  <br /><br />
                  With 5+ years of experience exploring the intersection of technology and business, I started InsightSphere with a simple goal: help curious people learn something new every single day. Whether it's the latest breakthroughs in artificial intelligence, proven strategies for building wealth, or step-by-step guides to mastering the digital world — I cover it all with depth, clarity, and honesty.
                </p>
                {/* Topics */}
                <div className="mb-6">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Writes About</p>
                  <div className="flex flex-wrap justify-center md:justify-start gap-2">
                    {TOPICS.map((topic) => (
                      <Badge key={topic} variant="outline" className="text-xs">{topic}</Badge>
                    ))}
                  </div>
                </div>
                {/* Social */}
                <div className="flex items-center justify-center md:justify-start gap-3">
                  <a
                    href="mailto:shivxx888@gmail.com"
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    <span>shivxx888@gmail.com</span>
                  </a>
                  <span className="text-muted-foreground/30">|</span>
                  <a
                    href="https://twitter.com/InsightSphere"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Twitter className="w-4 h-4" />
                    <span>Twitter</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Topics We Cover */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-6 text-center">What We Cover</h2>
            <div className="flex flex-wrap justify-center gap-3">
              {TOPICS.map((topic, i) => (
                <motion.span
                  key={topic}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-2 text-sm font-medium"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  {topic}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Contact CTA */}
          <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-8 text-center">
            <Globe className="w-8 h-8 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-foreground mb-3">Get in Touch</h2>
            <p className="text-muted-foreground mb-4 max-w-md mx-auto">
              Have a question, collaboration idea, or just want to say hello? I'd love to hear from you.
            </p>
            <a href="mailto:shivxx888@gmail.com" className="text-primary font-semibold hover:underline text-lg">
              shivxx888@gmail.com
            </a>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
