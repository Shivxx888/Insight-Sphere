import { useState, useEffect, useRef } from "react";
import { useRoute, Link } from "wouter";
import {
  Clock, Eye, Heart, Bookmark, Share2, ChevronRight, MessageCircle, Twitter, Linkedin, Facebook, Copy
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { PostCard } from "@/components/PostCard";
import Layout from "@/components/Layout";
import { AdSlotInArticle, AdSlotRectangle } from "@/components/AdSlot";
import {
  useGetPost,
  getGetPostQueryKey,
  useListRelatedPosts,
  getListRelatedPostsQueryKey,
  useListComments,
  getListCommentsQueryKey,
  useCreateComment,
  useLikePost,
  useBookmarkPost,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

function AuthorAvatar({
  name,
  avatar,
  className,
}: {
  name: string;
  avatar?: string | null;
  className?: string;
}) {
  if (avatar && avatar.startsWith("http")) {
    return (
      <img
        src={avatar}
        alt={name}
        className={`object-cover ${className ?? ""}`}
        loading="lazy"
      />
    );
  }
  return (
    <div
      className={`bg-gradient-to-br from-primary via-primary/80 to-primary/60 flex items-center justify-center text-white font-bold ${className ?? ""}`}
    >
      {name[0]?.toUpperCase() ?? "S"}
    </div>
  );
}

function ReadingProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(total > 0 ? (window.scrollY / total) * 100 : 0);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="fixed top-16 left-0 right-0 z-30 h-0.5 bg-muted" data-testid="reading-progress">
      <div className="h-full bg-primary transition-all duration-100" style={{ width: `${progress}%` }} />
    </div>
  );
}

function TableOfContents({ content }: { content: string }) {
  const headings = content.match(/^#{2,3}\s+.+$/gm) ?? [];
  const items = headings.map((h) => {
    const level = h.match(/^(#{2,3})/)?.[1].length ?? 2;
    const text = h.replace(/^#{2,3}\s+/, "");
    const id = text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    return { level, text, id };
  });
  if (items.length === 0) return null;
  return (
    <nav className="bg-card border border-border rounded-xl p-5 sticky top-24" data-testid="table-of-contents">
      <h4 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wider">Contents</h4>
      <ol className="space-y-1.5">
        {items.map((item, i) => (
          <li key={i} className={item.level === 3 ? "pl-4" : ""}>
            <a
              href={`#${item.id}`}
              className="text-xs text-muted-foreground hover:text-primary transition-colors line-clamp-2"
              data-testid={`toc-item-${i}`}
            >
              {item.text}
            </a>
          </li>
        ))}
      </ol>
    </nav>
  );
}

function ShareButtons({ title, slug }: { title: string; slug: string }) {
  const { toast } = useToast();
  const url = `${window.location.origin}/blog/${slug}`;
  const copy = () => {
    navigator.clipboard.writeText(url);
    toast({ title: "Link copied!", description: "Article URL copied to clipboard." });
  };
  return (
    <div className="flex items-center gap-2 flex-wrap" data-testid="share-buttons">
      <span className="text-sm text-muted-foreground mr-1 flex items-center gap-1">
        <Share2 className="w-4 h-4" /> Share:
      </span>
      <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer">
        <Button variant="outline" size="icon" className="w-8 h-8 rounded-full" data-testid="share-twitter"><Twitter className="w-3.5 h-3.5" /></Button>
      </a>
      <a href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer">
        <Button variant="outline" size="icon" className="w-8 h-8 rounded-full" data-testid="share-linkedin"><Linkedin className="w-3.5 h-3.5" /></Button>
      </a>
      <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer">
        <Button variant="outline" size="icon" className="w-8 h-8 rounded-full" data-testid="share-facebook"><Facebook className="w-3.5 h-3.5" /></Button>
      </a>
      <Button variant="outline" size="icon" className="w-8 h-8 rounded-full" onClick={copy} data-testid="share-copy"><Copy className="w-3.5 h-3.5" /></Button>
    </div>
  );
}

function renderMarkdownContent(content: string) {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let i = 0;
  let adCount = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (line.startsWith("## ")) {
      const text = line.replace(/^## /, "");
      const id = text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
      elements.push(<h2 key={i} id={id} className="text-2xl font-bold text-foreground mt-8 mb-4">{text}</h2>);
      if (adCount === 0 && elements.length > 8) {
        adCount++;
        elements.push(<AdSlotInArticle key={`ad-${i}`} />);
      }
    } else if (line.startsWith("### ")) {
      const text = line.replace(/^### /, "");
      const id = text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
      elements.push(<h3 key={i} id={id} className="text-xl font-bold text-foreground mt-6 mb-3">{text}</h3>);
    } else if (line.startsWith("**") && line.endsWith("**") && !line.slice(2, -2).includes("**")) {
      elements.push(<p key={i} className="font-semibold text-foreground mb-3">{line.replace(/\*\*/g, "")}</p>);
    } else if (line.startsWith("- ")) {
      elements.push(<li key={i} className="text-foreground/90 ml-6 mb-1.5 list-disc leading-relaxed">{line.replace(/^- /, "")}</li>);
    } else if (line.match(/^\d+\. /)) {
      const text = line.replace(/^\d+\. /, "");
      elements.push(<li key={i} className="text-foreground/90 ml-6 mb-1.5 list-decimal leading-relaxed">{text}</li>);
    } else if (line.startsWith("> ")) {
      elements.push(
        <blockquote key={i} className="border-l-4 border-primary pl-4 py-2 my-4 italic text-muted-foreground bg-muted/30 rounded-r-lg">
          {line.replace(/^> /, "")}
        </blockquote>
      );
    } else if (line.startsWith("```") || line.startsWith("    ")) {
      elements.push(
        <pre key={i} className="bg-muted rounded-lg p-4 my-4 overflow-x-auto text-sm font-mono text-foreground/90">
          <code>{line.replace(/^```\w*/, "").trim()}</code>
        </pre>
      );
    } else if (line.trim()) {
      const withBold = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      const withItalic = withBold.replace(/\*(.+?)\*/g, "<em>$1</em>");
      const withCode = withItalic.replace(/`(.+?)`/g, '<code class="bg-muted px-1.5 py-0.5 rounded text-sm font-mono">$1</code>');
      elements.push(
        <p key={i} className="text-foreground/90 leading-[1.85] mb-4" dangerouslySetInnerHTML={{ __html: withCode }} />
      );
    }
    i++;
  }
  return elements;
}

function setMetaTag(property: string, content: string, isName = false) {
  const attr = isName ? "name" : "property";
  let el = document.querySelector(`meta[${attr}="${property}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, property);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setJsonLd(id: string, data: object) {
  let el = document.getElementById(id) as HTMLScriptElement | null;
  if (!el) {
    el = document.createElement("script");
    el.id = id;
    el.type = "application/ld+json";
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(data);
}

export default function ArticlePage() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug ?? "";
  const { data: post, isLoading } = useGetPost(slug, { query: { enabled: !!slug, queryKey: getGetPostQueryKey(slug) } });
  const { data: related } = useListRelatedPosts(slug, { query: { enabled: !!slug, queryKey: getListRelatedPostsQueryKey(slug) } });
  const { data: comments } = useListComments(slug, { query: { enabled: !!slug, queryKey: getListCommentsQueryKey(slug) } });
  const createComment = useCreateComment();
  const likePost = useLikePost();
  const bookmarkPost = useBookmarkPost();
  const { toast } = useToast();

  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [commentName, setCommentName] = useState("");
  const [commentEmail, setCommentEmail] = useState("");
  const [commentText, setCommentText] = useState("");

  useEffect(() => {
    if (!post) return;
    const title = `${post.metaTitle || post.title} | InsightSphere`;
    const description = post.metaDescription || post.excerpt;
    const image = post.coverImage || `https://insightsphere.replit.app/opengraph.jpg`;
    const url = window.location.href;

    document.title = title;

    setMetaTag("description", description, true);
    setMetaTag("og:title", post.title);
    setMetaTag("og:description", description);
    setMetaTag("og:image", image);
    setMetaTag("og:url", url);
    setMetaTag("og:type", "article");
    setMetaTag("og:site_name", "InsightSphere");
    setMetaTag("article:author", "Shivam");
    setMetaTag("article:section", post.category.name);
    if (post.publishedAt) setMetaTag("article:published_time", post.publishedAt);
    setMetaTag("twitter:card", "summary_large_image", true);
    setMetaTag("twitter:title", post.title, true);
    setMetaTag("twitter:description", description, true);
    setMetaTag("twitter:image", image, true);
    setMetaTag("twitter:site", "@InsightSphere", true);

    let canonicalEl = document.querySelector("link[rel='canonical']") as HTMLLinkElement | null;
    if (!canonicalEl) {
      canonicalEl = document.createElement("link");
      canonicalEl.rel = "canonical";
      document.head.appendChild(canonicalEl);
    }
    canonicalEl.href = url;

    setJsonLd("article-schema", {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": post.title,
      "description": description,
      "image": image,
      "datePublished": post.publishedAt,
      "dateModified": post.publishedAt,
      "author": {
        "@type": "Person",
        "name": "Shivam",
        "url": "https://insightsphere.replit.app/about",
      },
      "publisher": {
        "@type": "Organization",
        "name": "InsightSphere",
        "logo": {
          "@type": "ImageObject",
          "url": "https://insightsphere.replit.app/favicon.svg",
        },
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": url,
      },
      "articleSection": post.category.name,
      "keywords": post.tags.join(", "),
      "wordCount": post.content.split(" ").length,
    });

    return () => {
      document.title = "InsightSphere — Learn Something New Every Day";
    };
  }, [post]);

  const handleLike = () => {
    if (!liked && post) {
      likePost.mutate({ slug: post.slug });
      setLiked(true);
    }
  };

  const handleBookmark = () => {
    if (post) {
      bookmarkPost.mutate({ slug: post.slug });
      setBookmarked(!bookmarked);
      toast({ title: bookmarked ? "Removed from bookmarks" : "Bookmarked!", description: bookmarked ? "" : "Article saved to your bookmarks." });
    }
  };

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    createComment.mutate(
      { slug, data: { authorName: commentName, authorEmail: commentEmail, content: commentText } },
      {
        onSuccess: () => {
          toast({ title: "Comment submitted!", description: "Your comment is pending review." });
          setCommentName(""); setCommentEmail(""); setCommentText("");
        },
      }
    );
  };

  if (isLoading) {
    return (
      <Layout>
        <ReadingProgress />
        <div className="max-w-4xl mx-auto px-4 py-10">
          <Skeleton className="h-10 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <Skeleton className="h-64 rounded-2xl mb-8" />
          <div className="space-y-3">
            {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-4 w-full" />)}
          </div>
        </div>
      </Layout>
    );
  }

  if (!post) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">Article Not Found</h1>
          <p className="text-muted-foreground mb-6">The article you're looking for doesn't exist or has been moved.</p>
          <Link href="/blog"><Button>Browse All Articles</Button></Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <ReadingProgress />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8" data-testid="page-article">

        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6 flex-wrap" aria-label="Breadcrumb">
          <Link href="/"><span className="hover:text-primary cursor-pointer">Home</span></Link>
          <ChevronRight className="w-3 h-3" />
          <Link href="/blog"><span className="hover:text-primary cursor-pointer">Blog</span></Link>
          <ChevronRight className="w-3 h-3" />
          <Link href={`/categories/${post.category.slug}`}>
            <span className="hover:text-primary cursor-pointer">{post.category.name}</span>
          </Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-foreground line-clamp-1 max-w-xs">{post.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
          {/* Main Content */}
          <article className="lg:col-span-3">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <Badge style={{ backgroundColor: post.category.color, color: "#fff" }}>{post.category.name}</Badge>
                {post.tags.slice(0, 3).map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                ))}
              </div>

              <h1 className="text-3xl md:text-4xl font-bold text-foreground leading-tight mb-4" data-testid="article-title">
                {post.title}
              </h1>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">{post.excerpt}</p>

              {/* Author & Meta */}
              <div className="flex flex-wrap items-center gap-4 mb-6 pb-6 border-b border-border">
                <div className="flex items-center gap-3">
                  <AuthorAvatar
                    name={post.author.name}
                    avatar={post.author.avatar}
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Written by {post.author.name}</p>
                    <p className="text-xs text-muted-foreground">{post.author.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {post.readingTime} min read
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    {post.viewCount?.toLocaleString()} views
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-3.5 h-3.5" />
                    {post.commentCount} comments
                  </span>
                  {post.publishedAt && (
                    <span>
                      {new Date(post.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
                    </span>
                  )}
                </div>
              </div>

              {/* Cover Image */}
              <div className="rounded-2xl overflow-hidden mb-8 aspect-video bg-muted">
                <img
                  src={post.coverImage || `https://picsum.photos/seed/${post.id}/1200/600`}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  loading="eager"
                />
              </div>

              {/* Article Content */}
              <div className="prose-custom max-w-none">
                {renderMarkdownContent(post.content)}
              </div>

              {/* Tags */}
              {post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-border">
                  <span className="text-sm text-muted-foreground mr-1">Tags:</span>
                  {post.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs cursor-pointer hover:bg-primary hover:text-white transition-colors">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="flex flex-wrap items-center justify-between gap-4 mt-6 pt-6 border-t border-border">
                <div className="flex items-center gap-3">
                  <Button
                    variant={liked ? "default" : "outline"}
                    size="sm"
                    className="gap-2"
                    onClick={handleLike}
                    data-testid="button-like"
                  >
                    <Heart className={`w-4 h-4 ${liked ? "fill-current" : ""}`} />
                    {(post.likeCount ?? 0) + (liked ? 1 : 0)} Likes
                  </Button>
                  <Button
                    variant={bookmarked ? "default" : "outline"}
                    size="sm"
                    className="gap-2"
                    onClick={handleBookmark}
                    data-testid="button-bookmark"
                  >
                    <Bookmark className={`w-4 h-4 ${bookmarked ? "fill-current" : ""}`} />
                    {bookmarked ? "Saved" : "Save"}
                  </Button>
                </div>
                <ShareButtons title={post.title} slug={post.slug} />
              </div>

              {/* Author Box */}
              <div className="bg-gradient-to-br from-primary/5 via-primary/3 to-transparent border border-primary/15 rounded-2xl p-6 mt-10" data-testid="author-box">
                <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">About the Author</h3>
                <div className="flex items-start gap-4">
                  <AuthorAvatar
                    name={post.author.name}
                    avatar={post.author.avatar}
                    className="w-16 h-16 rounded-full shrink-0"
                  />
                  <div>
                    <p className="font-bold text-foreground">Written by {post.author.name}</p>
                    <p className="text-sm text-primary mb-2">{post.author.role}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{post.author.bio}</p>
                  </div>
                </div>
              </div>

              {/* Ad slot after author box */}
              <AdSlotBannerSection />

              {/* Comments */}
              <div className="mt-12" data-testid="comments-section">
                <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-primary" />
                  Comments ({comments?.length ?? 0})
                </h3>
                <div className="space-y-4 mb-8">
                  {comments?.map((comment) => (
                    <div key={comment.id} className="bg-card border border-border rounded-xl p-4" data-testid={`comment-${comment.id}`}>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                          {comment.authorName[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{comment.authorName}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(comment.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                          </p>
                        </div>
                      </div>
                      <p className="text-sm text-foreground/90 pl-11 leading-relaxed">{comment.content}</p>
                    </div>
                  ))}
                  {(!comments || comments.length === 0) && (
                    <p className="text-muted-foreground text-sm">No comments yet. Be the first to share your thoughts!</p>
                  )}
                </div>

                {/* Comment Form */}
                <div className="bg-card border border-border rounded-2xl p-6">
                  <h4 className="font-bold text-foreground mb-4">Leave a Comment</h4>
                  <form onSubmit={handleComment} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <Input placeholder="Your name *" value={commentName} onChange={(e) => setCommentName(e.target.value)} required data-testid="input-comment-name" />
                      <Input type="email" placeholder="Your email *" value={commentEmail} onChange={(e) => setCommentEmail(e.target.value)} required data-testid="input-comment-email" />
                    </div>
                    <Textarea
                      placeholder="Write your comment..."
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      required
                      rows={4}
                      data-testid="textarea-comment"
                    />
                    <p className="text-xs text-muted-foreground">Your email will not be published. Required fields are marked *</p>
                    <Button type="submit" disabled={createComment.isPending} data-testid="button-submit-comment">
                      {createComment.isPending ? "Posting..." : "Post Comment"}
                    </Button>
                  </form>
                </div>
              </div>
            </motion.div>
          </article>

          {/* Sidebar */}
          <aside className="hidden lg:block space-y-6">
            <TableOfContents content={post.content} />
            <AdSlotRectangle />
          </aside>
        </div>

        {/* Related Posts */}
        {related && related.length > 0 && (
          <section className="mt-16 pt-10 border-t border-border" data-testid="section-related">
            <h3 className="text-2xl font-bold text-foreground mb-8">Related Articles</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {related.slice(0, 3).map((p) => (
                <PostCard key={p.id} post={p} variant="default" />
              ))}
            </div>
          </section>
        )}
      </div>
    </Layout>
  );
}

function AdSlotBannerSection() {
  return (
    <div className="my-8 p-1">
      <AdSlotInArticle />
    </div>
  );
}
