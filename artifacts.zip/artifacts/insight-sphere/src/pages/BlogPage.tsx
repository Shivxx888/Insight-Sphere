import { useState } from "react";
import { Filter } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PostCard } from "@/components/PostCard";
import Layout from "@/components/Layout";
import { useListPosts, useListCategories } from "@workspace/api-client-react";

export default function BlogPage() {
  const [page, setPage] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();

  const { data, isLoading } = useListPosts(
    { page, limit: 12, category: selectedCategory },
    { query: { queryKey: ["posts", page, selectedCategory] } }
  );
  const { data: categories } = useListCategories();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10" data-testid="page-blog">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-foreground mb-2">All Articles</h1>
          <p className="text-muted-foreground">Explore our collection of expert-written articles</p>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2 flex-wrap mb-8" data-testid="category-filter">
          <div className="flex items-center gap-1 text-sm text-muted-foreground mr-2">
            <Filter className="w-4 h-4" /> Filter:
          </div>
          <Button
            variant={!selectedCategory ? "default" : "outline"}
            size="sm"
            className="rounded-full text-xs"
            onClick={() => { setSelectedCategory(undefined); setPage(1); }}
            data-testid="filter-all"
          >
            All
          </Button>
          {categories?.map((cat) => (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.slug ? "default" : "outline"}
              size="sm"
              className="rounded-full text-xs"
              onClick={() => { setSelectedCategory(cat.slug); setPage(1); }}
              data-testid={`filter-${cat.slug}`}
            >
              {cat.name}
            </Button>
          ))}
        </div>

        {/* Posts Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(12)].map((_, i) => <Skeleton key={i} className="h-80 rounded-2xl" />)}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {data?.posts.map((post) => (
              <PostCard key={post.id} post={post} variant="default" />
            ))}
          </motion.div>
        )}

        {/* Pagination */}
        {data && data.totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-12" data-testid="pagination">
            <Button
              variant="outline"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              data-testid="button-prev-page"
            >
              Previous
            </Button>
            <div className="flex gap-1">
              {[...Array(Math.min(data.totalPages, 5))].map((_, i) => {
                const p = i + 1;
                return (
                  <Button
                    key={p}
                    variant={page === p ? "default" : "outline"}
                    size="sm"
                    className="w-9"
                    onClick={() => setPage(p)}
                    data-testid={`button-page-${p}`}
                  >
                    {p}
                  </Button>
                );
              })}
            </div>
            <Button
              variant="outline"
              onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
              disabled={page === data.totalPages}
              data-testid="button-next-page"
            >
              Next
            </Button>
          </div>
        )}

        {data?.posts.length === 0 && (
          <div className="text-center py-24">
            <p className="text-xl text-muted-foreground">No articles found.</p>
            <Button className="mt-4" onClick={() => { setSelectedCategory(undefined); setPage(1); }}>
              Clear filters
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
