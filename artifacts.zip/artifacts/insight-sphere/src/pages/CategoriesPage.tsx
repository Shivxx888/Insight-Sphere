import { Link } from "wouter";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import Layout from "@/components/Layout";
import { useListCategories } from "@workspace/api-client-react";

const CATEGORY_ICONS: Record<string, string> = {
  "artificial-intelligence": "🤖",
  technology: "💻",
  finance: "💰",
  "make-money-online": "💵",
  business: "📊",
  education: "📚",
  "digital-marketing": "📣",
  cybersecurity: "🔒",
  "mobile-apps": "📱",
  "how-to-guides": "🔧",
};

export default function CategoriesPage() {
  const { data: categories, isLoading } = useListCategories();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10" data-testid="page-categories">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-foreground mb-2">Categories</h1>
          <p className="text-muted-foreground">Explore articles by topic area</p>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(10)].map((_, i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categories?.map((cat, i) => (
              <Link key={cat.id} href={`/categories/${cat.slug}`}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  whileHover={{ scale: 1.02, y: -2 }}
                  className="group cursor-pointer bg-card border border-border rounded-2xl p-6 hover:shadow-lg hover:border-primary/30 transition-all"
                  data-testid={`card-category-${cat.id}`}
                >
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl mb-4"
                    style={{ backgroundColor: `${cat.color}20` }}
                  >
                    {CATEGORY_ICONS[cat.slug] ?? "📰"}
                  </div>
                  <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors mb-1">
                    {cat.name}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{cat.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-muted-foreground">{cat.postCount} articles</span>
                    <div className="w-5 h-5 rounded-full" style={{ backgroundColor: cat.color }} />
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
