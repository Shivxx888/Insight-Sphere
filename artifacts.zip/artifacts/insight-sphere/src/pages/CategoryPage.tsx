import { useRoute, Link } from "wouter";
import { ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { PostCard } from "@/components/PostCard";
import Layout from "@/components/Layout";
import { useGetCategory, getGetCategoryQueryKey, useListPosts } from "@workspace/api-client-react";

export default function CategoryPage() {
  const [, params] = useRoute("/categories/:slug");
  const slug = params?.slug ?? "";
  const { data: category, isLoading: catLoading } = useGetCategory(slug, {
    query: { enabled: !!slug, queryKey: getGetCategoryQueryKey(slug) },
  });
  const { data: postsData, isLoading: postsLoading } = useListPosts(
    { category: slug, limit: 12 },
    { query: { enabled: !!slug, queryKey: ["posts-by-cat", slug] } }
  );

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10" data-testid="page-category">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/"><span className="hover:text-primary cursor-pointer">Home</span></Link>
          <ChevronRight className="w-3 h-3" />
          <Link href="/categories"><span className="hover:text-primary cursor-pointer">Categories</span></Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-foreground">{category?.name ?? slug}</span>
        </nav>

        {catLoading ? (
          <div className="mb-10">
            <Skeleton className="h-10 w-48 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
        ) : category ? (
          <div className="mb-10">
            <div className="flex items-center gap-4 mb-3">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${category.color}20` }}
              >
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-foreground">{category.name}</h1>
                <p className="text-muted-foreground mt-1">{category.description}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">{category.postCount} articles in this category</p>
          </div>
        ) : null}

        {postsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-80 rounded-2xl" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {postsData?.posts.map((post) => (
              <PostCard key={post.id} post={post} variant="default" />
            ))}
          </div>
        )}

        {postsData?.posts.length === 0 && (
          <div className="text-center py-24">
            <p className="text-xl text-muted-foreground">No articles in this category yet.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
