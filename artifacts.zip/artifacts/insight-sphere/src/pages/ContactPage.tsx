import { useState } from "react";
import { Mail, MapPin, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Layout from "@/components/Layout";
import { useSubmitContact } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const submit = useSubmitContact();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submit.mutate(
      { data: form },
      {
        onSuccess: (data) => {
          toast({ title: "Message sent!", description: data.message });
          setForm({ name: "", email: "", subject: "", message: "" });
        },
      }
    );
  };

  return (
    <Layout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16" data-testid="page-contact">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-3">Contact Us</h1>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Have a question, tip, or just want to connect? We'd love to hear from you.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="space-y-6">
              {[
                { icon: <Mail className="w-5 h-5 text-primary" />, label: "Email", value: "shivxx888@gmail.com" },
                { icon: <MapPin className="w-5 h-5 text-primary" />, label: "Location", value: "Global — we're a distributed team" },
                { icon: <Clock className="w-5 h-5 text-primary" />, label: "Response Time", value: "Within 24–48 hours" },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-4 p-5 bg-card border border-border rounded-xl" data-testid={`contact-info-${i}`}>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">{item.icon}</div>
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">{item.label}</p>
                    <p className="text-sm text-foreground">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-8">
              <h2 className="text-xl font-bold text-foreground mb-6">Send a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block">Name *</label>
                    <Input
                      placeholder="Your full name"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      required
                      data-testid="input-contact-name"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block">Email *</label>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      required
                      data-testid="input-contact-email"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Subject *</label>
                  <Input
                    placeholder="What's this about?"
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    required
                    data-testid="input-contact-subject"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Message *</label>
                  <Textarea
                    placeholder="Tell us more..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    required
                    rows={5}
                    data-testid="textarea-contact-message"
                  />
                </div>
                <Button type="submit" disabled={submit.isPending} className="w-full" data-testid="button-send-message">
                  {submit.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
