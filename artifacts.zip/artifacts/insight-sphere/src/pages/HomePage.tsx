import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, TrendingUp, Zap, Users, Bell, BookOpen } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { PostCard } from "@/components/PostCard";
import Layout from "@/components/Layout";
import { AdSlotBanner, AdSlotRectangle } from "@/components/AdSlot";
import {
  useListFeaturedPosts,
  useListLatestPosts,
  useListTrendingPosts,
  useListCategories,
  useListAuthors,
  useListRecentComments,
  useSubscribeNewsletter,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

const CATEGORY_ICONS: Record<string, string> = {
  "artificial-intelligence": "🤖",
  technology: "💻",
  finance: "💰",
  "make-money-online": "💵",
  business: "📊",
  education: "📚",
  "digital-marketing": "📣",
  cybersecurity: "🔒",
  "mobile-apps": "📱",
  "how-to-guides": "🔧",
};

function AuthorAvatar({ name, avatar, className }: { name: string; avatar?: string | null; className?: string }) {
  if (avatar && avatar.startsWith("http")) {
    return <img src={avatar} alt={name} className={`object-cover ${className ?? ""}`} loading="lazy" />;
  }
  return (
    <div className={`bg-gradient-to-br from-primary via-primary/80 to-primary/60 flex items-center justify-center text-white font-bold ${className ?? ""}`}>
      {name[0]?.toUpperCase() ?? "S"}
    </div>
  );
}

function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const subscribe = useSubscribeNewsletter();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    subscribe.mutate(
      { data: { email, name } },
      {
        onSuccess: (data) => {
          toast({ title: data.success ? "Subscribed!" : "Already subscribed", description: data.message });
          setEmail("");
          setName("");
        },
      }
    );
  };

  return (
    <section className="py-16" data-testid="section-newsletter">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-3xl p-10"
        >
          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Bell className="w-6 h-6 text-primary" />
          </div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Stay in the Loop</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            Get the latest articles on AI, technology, finance, and business delivered straight to your inbox. No spam, ever.
          </p>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <Input
              type="text"
              placeholder="Your name (optional)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="flex-1"
              data-testid="input-newsletter-name"
            />
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1"
              data-testid="input-newsletter-email"
            />
            <Button type="submit" disabled={subscribe.isPending} data-testid="button-newsletter-subscribe">
              {subscribe.isPending ? "Subscribing..." : "Subscribe"}
            </Button>
          </form>
          <p className="text-xs text-muted-foreground mt-3">Join our growing community. Unsubscribe anytime.</p>
        </motion.div>
      </div>
    </section>
  );
}

export default function HomePage() {
  const { data: featured, isLoading: featuredLoading } = useListFeaturedPosts();
  const { data: latest, isLoading: latestLoading } = useListLatestPosts({ limit: 6 });
  const { data: trending } = useListTrendingPosts({ limit: 5 });
  const { data: categories } = useListCategories();
  const { data: authors } = useListAuthors();
  const { data: recentComments } = useListRecentComments({ limit: 4 });

  const heroPost = featured?.[0];
  const secondaryFeatured = featured?.slice(1, 3) ?? [];

  const hasContent = featuredLoading || (featured && featured.length > 0);

  return (
    <Layout>
      {/* Hero Section */}
      {hasContent && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-10 pb-8" data-testid="section-hero">
          {featuredLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2"><Skeleton className="h-[480px] rounded-2xl" /></div>
              <div className="space-y-4">
                <Skeleton className="h-[230px] rounded-2xl" />
                <Skeleton className="h-[230px] rounded-2xl" />
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6"
            >
              {heroPost && (
                <div className="lg:col-span-2">
                  <PostCard post={heroPost} variant="featured" />
                </div>
              )}
              <div className="space-y-4">
                {secondaryFeatured.map((post) => (
                  <PostCard key={post.id} post={post} variant="featured" />
                ))}
                {secondaryFeatured.length === 0 && trending?.slice(0, 2).map((post) => (
                  <PostCard key={post.id} post={post} variant="default" />
                ))}
              </div>
            </motion.div>
          )}
        </section>
      )}

      {/* Welcome banner when no posts exist */}
      {!featuredLoading && (!featured || featured.length === 0) && (
        <section className="max-w-4xl mx-auto px-4 sm:px-6 pt-16 pb-8 text-center" data-testid="section-welcome">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="w-20 h-20 bg-gradient-to-br from-primary via-primary/80 to-primary/60 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <span className="text-3xl font-black text-white">IS</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Welcome to <span className="text-primary">InsightSphere</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-xl mx-auto">
              Learn Something New Every Day. New articles on AI, technology, finance, and digital business coming soon.
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Link href="/blog"><Button size="lg" className="gap-2"><BookOpen className="w-4 h-4" /> Browse Articles</Button></Link>
              <Link href="/categories"><Button size="lg" variant="outline" className="gap-2">Explore Topics <ArrowRight className="w-4 h-4" /></Button></Link>
            </div>
          </motion.div>
        </section>
      )}

      {/* Stats bar */}
      <section className="border-y border-border bg-muted/30 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-muted-foreground">
            {[
              { icon: <Zap className="w-4 h-4 text-primary" />, label: "Fresh Insights Daily" },
              { icon: <Users className="w-4 h-4 text-primary" />, label: "Expert Coverage" },
              { icon: <TrendingUp className="w-4 h-4 text-primary" />, label: "10 Topics Covered" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2">
                {item.icon}
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ad Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <AdSlotBanner />
      </div>

      {/* Latest Articles */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-14" data-testid="section-latest">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Latest Articles</h2>
            <p className="text-muted-foreground text-sm mt-1">Fresh insights, updated regularly</p>
          </div>
          <Link href="/blog">
            <Button variant="ghost" className="gap-2 text-primary" data-testid="link-view-all-posts">
              View all <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
        {latestLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-80 rounded-2xl" />)}
          </div>
        ) : latest && latest.length > 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {latest.map((post) => (
              <PostCard key={post.id} post={post} variant="default" />
            ))}
          </motion.div>
        ) : null}
      </section>

      {/* Trending + Categories + Sidebar layout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-14">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-10">
            {/* Popular Categories */}
            <div data-testid="section-categories">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-foreground">Popular Categories</h2>
                <Link href="/categories">
                  <Button variant="ghost" size="sm" className="text-primary gap-1">
                    All <ArrowRight className="w-3 h-3" />
                  </Button>
                </Link>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {categories?.slice(0, 6).map((cat) => (
                  <Link key={cat.id} href={`/categories/${cat.slug}`}>
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      className="group flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer"
                      data-testid={`card-category-${cat.id}`}
                    >
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center text-lg shrink-0" style={{ backgroundColor: `${cat.color}20` }}>
                        {CATEGORY_ICONS[cat.slug] ?? "📰"}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{cat.name}</p>
                        <p className="text-xs text-muted-foreground">{cat.postCount} {cat.postCount === 1 ? "post" : "posts"}</p>
                      </div>
                    </motion.div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Author Profile */}
            <div data-testid="section-authors">
              <h2 className="text-2xl font-bold text-foreground mb-6">About the Author</h2>
              {authors?.slice(0, 1).map((author) => (
                <div key={author.id} className="flex items-center gap-5 p-6 rounded-2xl bg-card border border-border" data-testid={`card-author-${author.id}`}>
                  <AuthorAvatar
                    name={author.name}
                    avatar={author.avatar}
                    className="w-16 h-16 rounded-full shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-foreground">{author.name}</p>
                    <p className="text-xs text-primary mb-2">{author.role}</p>
                    <p className="text-sm text-muted-foreground line-clamp-2">{author.bio}</p>
                    <Link href="/about">
                      <Button variant="link" className="p-0 h-auto text-xs mt-2">Read more →</Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Trending Posts */}
            <div className="bg-card border border-border rounded-2xl p-6" data-testid="section-trending">
              <div className="flex items-center gap-2 mb-5">
                <TrendingUp className="w-5 h-5 text-primary" />
                <h3 className="font-bold text-foreground">Trending Posts</h3>
              </div>
              {trending && trending.length > 0 ? (
                <div className="space-y-1">
                  {trending.map((post, i) => (
                    <div key={post.id} className="flex items-start gap-3 py-3 border-b border-border last:border-0">
                      <span className="text-2xl font-black text-muted-foreground/30 leading-none mt-1 w-6 shrink-0">{i + 1}</span>
                      <PostCard post={post} variant="compact" />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No trending posts yet.</p>
              )}
            </div>

            {/* Ad slot in sidebar */}
            <AdSlotRectangle />

            {/* Recent Comments */}
            <div className="bg-card border border-border rounded-2xl p-6" data-testid="section-recent-comments">
              <h3 className="font-bold text-foreground mb-5">Recent Comments</h3>
              <div className="space-y-4">
                {recentComments?.map((comment) => (
                  <div key={comment.id} className="text-sm" data-testid={`comment-${comment.id}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                        {comment.authorName[0]?.toUpperCase()}
                      </div>
                      <span className="font-medium text-foreground text-xs">{comment.authorName}</span>
                    </div>
                    <p className="text-muted-foreground line-clamp-2 text-xs pl-8">{comment.content}</p>
                    <Link href={`/blog/${comment.postSlug}`}>
                      <p className="text-primary text-xs pl-8 mt-1 hover:underline cursor-pointer line-clamp-1">{comment.postTitle}</p>
                    </Link>
                  </div>
                ))}
                {(!recentComments || recentComments.length === 0) && (
                  <p className="text-xs text-muted-foreground">No comments yet. Be the first to join the discussion!</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <NewsletterSection />
    </Layout>
  );
}
