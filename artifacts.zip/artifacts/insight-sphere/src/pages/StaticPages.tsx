import Layout from "@/components/Layout";

function StaticPage({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16" data-testid={`page-static-${title.toLowerCase().replace(/\s+/g, "-")}`}>
        <h1 className="text-4xl font-bold text-foreground mb-8">{title}</h1>
        <div className="prose prose-sm max-w-none text-foreground/80 space-y-4">{children}</div>
      </div>
    </Layout>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold text-foreground mb-3">{title}</h2>
      <div className="text-muted-foreground leading-relaxed space-y-2">{children}</div>
    </div>
  );
}

export function PrivacyPage() {
  return (
    <StaticPage title="Privacy Policy">
      <p className="text-muted-foreground mb-2">Last updated: July 3, 2026</p>
      <Section title="1. Information We Collect">
        <p>We collect information you provide directly, such as when you subscribe to our newsletter, submit a comment, or contact us. This may include your name and email address.</p>
        <p>We also collect information automatically through analytics tools, including pages visited, time spent on pages, and device type.</p>
      </Section>
      <Section title="2. How We Use Your Information">
        <p>We use collected information to: send newsletters, respond to inquiries, improve our content and services, and comply with legal obligations.</p>
      </Section>
      <Section title="3. Data Sharing">
        <p>We do not sell your personal information. We may share data with trusted third-party service providers (analytics, email delivery) solely to operate our service.</p>
      </Section>
      <Section title="4. Cookies">
        <p>We use cookies to improve your experience. You can control cookies through your browser settings or through our cookie consent banner.</p>
      </Section>
      <Section title="5. Your Rights">
        <p>You may request access to, correction of, or deletion of your personal data by contacting us at shivxx888@gmail.com.</p>
      </Section>
      <Section title="6. Contact">
        <p>Questions about this policy? Email us at shivxx888@gmail.com.</p>
      </Section>
    </StaticPage>
  );
}

export function TermsPage() {
  return (
    <StaticPage title="Terms & Conditions">
      <p className="text-muted-foreground mb-2">Last updated: July 3, 2026</p>
      <Section title="1. Acceptance of Terms">
        <p>By accessing or using InsightSphere, you agree to be bound by these Terms & Conditions and our Privacy Policy.</p>
      </Section>
      <Section title="2. Intellectual Property">
        <p>All content on InsightSphere — articles, images, graphics, and code — is the property of InsightSphere and is protected by applicable copyright laws. You may not reproduce or distribute content without permission.</p>
      </Section>
      <Section title="3. User Content">
        <p>By submitting comments, you grant InsightSphere a non-exclusive license to publish, modify, and remove that content at our discretion. You are responsible for ensuring your submissions don't violate any laws.</p>
      </Section>
      <Section title="4. Disclaimers">
        <p>Content on InsightSphere is for informational purposes only. We make no warranties about accuracy, completeness, or fitness for a particular purpose.</p>
      </Section>
      <Section title="5. Limitation of Liability">
        <p>InsightSphere shall not be liable for any indirect, incidental, or consequential damages arising from your use of the site.</p>
      </Section>
      <Section title="6. Changes to Terms">
        <p>We reserve the right to modify these terms at any time. Continued use of the site constitutes acceptance of the updated terms.</p>
      </Section>
      <Section title="7. Contact">
        <p>For questions, contact us at shivxx888@gmail.com.</p>
      </Section>
    </StaticPage>
  );
}

export function DisclaimerPage() {
  return (
    <StaticPage title="Disclaimer">
      <Section title="General Information Only">
        <p>The information published on InsightSphere is intended for general informational and educational purposes only. It does not constitute professional advice — financial, legal, medical, or otherwise.</p>
      </Section>
      <Section title="No Professional Relationship">
        <p>Reading content on InsightSphere does not create a professional relationship between you and InsightSphere or its authors. Always seek appropriate professional guidance before making important decisions.</p>
      </Section>
      <Section title="External Links">
        <p>Our content may contain links to third-party websites. InsightSphere is not responsible for the content, privacy practices, or accuracy of those sites.</p>
      </Section>
      <Section title="Affiliate Disclosure">
        <p>Some articles may contain affiliate links. If you click an affiliate link and make a purchase, InsightSphere may earn a commission at no extra cost to you. We only recommend products and services we genuinely believe in.</p>
      </Section>
      <Section title="Contact">
        <p>Questions about this disclaimer? Contact us at shivxx888@gmail.com.</p>
      </Section>
    </StaticPage>
  );
}

export function CookiePolicyPage() {
  return (
    <StaticPage title="Cookie Policy">
      <p className="text-muted-foreground mb-2">Last updated: July 3, 2026</p>
      <Section title="What Are Cookies?">
        <p>Cookies are small text files placed on your device when you visit a website. They help websites remember your preferences and understand how you use the site.</p>
      </Section>
      <Section title="Types of Cookies We Use">
        <p><strong>Essential Cookies:</strong> Required for the site to function (e.g., remembering your cookie consent choice, theme preference).</p>
        <p><strong>Analytics Cookies:</strong> Help us understand how visitors interact with InsightSphere so we can improve the experience.</p>
        <p><strong>Preference Cookies:</strong> Remember your settings such as dark/light mode.</p>
      </Section>
      <Section title="Managing Cookies">
        <p>You can control cookies through your browser settings. Disabling certain cookies may affect site functionality.</p>
      </Section>
      <Section title="Third-Party Cookies">
        <p>We may use third-party services (e.g., Google Analytics) that set their own cookies. These are governed by their respective privacy policies.</p>
      </Section>
      <Section title="Contact">
        <p>Questions? Email us at shivxx888@gmail.com.</p>
      </Section>
    </StaticPage>
  );
}
