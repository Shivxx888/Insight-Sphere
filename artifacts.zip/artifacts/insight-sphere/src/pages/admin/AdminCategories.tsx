import { useState } from "react";
import { Plus, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import AdminLayout from "./AdminLayout";
import { useListCategories, useCreateCategory } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function AdminCategories() {
  const { data: categories, isLoading } = useListCategories();
  const createCat = useCreateCategory();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", slug: "", description: "", color: "#3B82F6", icon: "Tag" });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createCat.mutate({ data: form }, {
      onSuccess: () => {
        toast({ title: "Category created!" });
        queryClient.invalidateQueries({ queryKey: ["categories"] });
        setShowForm(false);
        setForm({ name: "", slug: "", description: "", color: "#3B82F6", icon: "Tag" });
      },
    });
  };

  return (
    <AdminLayout>
      <div className="p-8" data-testid="page-admin-categories">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Categories</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage blog categories</p>
          </div>
          <Button className="gap-2" onClick={() => setShowForm(!showForm)} data-testid="button-new-category">
            <Plus className="w-4 h-4" /> New Category
          </Button>
        </div>

        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 mb-6">
            <h3 className="font-semibold text-foreground mb-4">Create Category</h3>
            <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Name *</label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value, slug: e.target.value.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "") })} required data-testid="input-cat-name" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Slug *</label>
                <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} required data-testid="input-cat-slug" />
              </div>
              <div className="sm:col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Description</label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} data-testid="textarea-cat-description" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Color</label>
                <div className="flex gap-2 items-center">
                  <input type="color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="h-9 w-14 rounded border border-input cursor-pointer" />
                  <Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="flex-1" data-testid="input-cat-color" />
                </div>
              </div>
              <div className="flex items-end gap-2 sm:col-span-2">
                <Button type="submit" disabled={createCat.isPending} data-testid="button-create-category">
                  {createCat.isPending ? "Creating..." : "Create"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {isLoading
            ? [...Array(6)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
            : categories?.map((cat) => (
                <div key={cat.id} className="bg-card border border-border rounded-xl p-5" data-testid={`category-card-${cat.id}`}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${cat.color}20` }}>
                      <Tag className="w-4 h-4" style={{ color: cat.color }} />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{cat.name}</p>
                      <p className="text-xs text-muted-foreground">{cat.slug}</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{cat.description}</p>
                  <p className="text-xs font-medium text-primary mt-2">{cat.postCount} posts</p>
                </div>
              ))}
        </div>
      </div>
    </AdminLayout>
  );
}
