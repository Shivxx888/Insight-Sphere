import { useState, useEffect } from "react";
import { Trash2, MessageSquare, ExternalLink, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import AdminLayout from "./AdminLayout";
import { adminFetch } from "@/lib/adminFetch";

interface AdminComment {
  id: number;
  content: string;
  authorName: string;
  authorEmail: string;
  createdAt: string;
  postId: number;
  postTitle: string | null;
  postSlug: string | null;
}

export default function AdminComments() {
  const [comments, setComments] = useState<AdminComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const { toast } = useToast();

  const fetchComments = async () => {
    setLoading(true);
    try {
      const data = await adminFetch<AdminComment[]>("/api/admin/all-comments");
      setComments(data);
    } catch {
      toast({ title: "Failed to load comments", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchComments(); }, []);

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this comment permanently?")) return;
    setDeleting(id);
    try {
      await adminFetch(`/api/admin/comment/${id}`, { method: "DELETE" });
      setComments((prev) => prev.filter((c) => c.id !== id));
      toast({ title: "Comment deleted" });
    } catch {
      toast({ title: "Failed to delete comment", variant: "destructive" });
    } finally {
      setDeleting(null);
    }
  };

  const filtered = comments.filter((c) =>
    c.content.toLowerCase().includes(search.toLowerCase()) ||
    c.authorName.toLowerCase().includes(search.toLowerCase()) ||
    (c.postTitle ?? "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="p-6 max-w-5xl" data-testid="page-admin-comments">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Comments</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {comments.length} total comment{comments.length !== 1 ? "s" : ""}
            </p>
          </div>
          <Button variant="outline" size="sm" className="gap-2" onClick={fetchComments} disabled={loading}>
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <Input
            placeholder="Search comments, authors, posts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-md"
          />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{comments.length}</p>
            <p className="text-xs text-muted-foreground mt-1">Total Comments</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">
              {new Set(comments.map((c) => c.postSlug)).size}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Posts with Comments</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">
              {new Set(comments.map((c) => c.authorEmail)).size}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Unique Commenters</p>
          </div>
        </div>

        {/* Comments list */}
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground">
              {search ? "No comments match your search." : "No comments yet."}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((comment) => (
              <div key={comment.id} className="bg-card border border-border rounded-xl p-5 hover:border-border/80 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <div className="w-7 h-7 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-primary">{comment.authorName[0]?.toUpperCase()}</span>
                      </div>
                      <span className="font-semibold text-sm text-foreground">{comment.authorName}</span>
                      <span className="text-xs text-muted-foreground">{comment.authorEmail}</span>
                      <span className="text-xs text-muted-foreground">·</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(comment.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </span>
                    </div>
                    <p className="text-sm text-foreground leading-relaxed mb-3 line-clamp-3">{comment.content}</p>
                    {comment.postSlug && (
                      <Link href={`/blog/${comment.postSlug}`}>
                        <div className="flex items-center gap-1.5 text-xs text-primary hover:underline cursor-pointer w-fit">
                          <ExternalLink className="w-3 h-3" />
                          <span className="truncate max-w-xs">{comment.postTitle ?? comment.postSlug}</span>
                        </div>
                      </Link>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 shrink-0"
                    onClick={() => handleDelete(comment.id)}
                    disabled={deleting === comment.id}
                    data-testid={`button-delete-comment-${comment.id}`}
                  >
                    {deleting === comment.id ? (
                      <div className="w-4 h-4 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
