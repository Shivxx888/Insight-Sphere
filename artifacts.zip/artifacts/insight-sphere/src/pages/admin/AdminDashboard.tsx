import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { FileText, Eye, MessageSquare, Mail, TrendingUp, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import AdminLayout from "./AdminLayout";
import { useGetAnalyticsOverview, useGetTopPosts, useGetCategoryBreakdown } from "@workspace/api-client-react";

const COLORS = ["#2563EB", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899", "#14B8A6", "#F97316", "#6366F1", "#3B82F6"];

export default function AdminDashboard() {
  const { data: overview, isLoading } = useGetAnalyticsOverview();
  const { data: topPosts } = useGetTopPosts({ limit: 8 });
  const { data: categoryBreakdown } = useGetCategoryBreakdown();

  const stats = [
    { label: "Total Posts", value: overview?.totalPosts ?? 0, icon: <FileText className="w-5 h-5" />, sub: `${overview?.publishedPosts ?? 0} published`, color: "text-blue-500" },
    { label: "Total Views", value: overview?.totalViews?.toLocaleString() ?? 0, icon: <Eye className="w-5 h-5" />, sub: "All time", color: "text-green-500" },
    { label: "Comments", value: overview?.totalComments ?? 0, icon: <MessageSquare className="w-5 h-5" />, sub: "All posts", color: "text-purple-500" },
    { label: "Subscribers", value: overview?.totalSubscribers ?? 0, icon: <Mail className="w-5 h-5" />, sub: "Newsletter", color: "text-amber-500" },
  ];

  return (
    <AdminLayout>
      <div className="p-8 max-w-7xl" data-testid="page-admin-dashboard">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">Overview of your blog's performance</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => (
            <div key={i} className="bg-card border border-border rounded-xl p-5" data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, "-")}`}>
              {isLoading ? (
                <Skeleton className="h-16 w-full" />
              ) : (
                <>
                  <div className={`${stat.color} mb-3`}>{stat.icon}</div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-sm font-medium text-foreground mt-0.5">{stat.label}</p>
                  <p className="text-xs text-muted-foreground">{stat.sub}</p>
                </>
              )}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
          {/* Top Posts Chart */}
          <div className="xl:col-span-2 bg-card border border-border rounded-xl p-6" data-testid="chart-top-posts">
            <div className="flex items-center gap-2 mb-5">
              <TrendingUp className="w-4 h-4 text-primary" />
              <h3 className="font-bold text-foreground text-sm">Top Posts by Views</h3>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={topPosts?.slice(0, 6).map((p) => ({ name: p.title.slice(0, 20) + "…", views: p.viewCount }))}>
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="views" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Category Breakdown */}
          <div className="bg-card border border-border rounded-xl p-6" data-testid="chart-categories">
            <h3 className="font-bold text-foreground text-sm mb-5">Posts by Category</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={categoryBreakdown?.map((c) => ({ name: c.name, value: c.postCount }))}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  dataKey="value"
                >
                  {categoryBreakdown?.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1 mt-3">
              {categoryBreakdown?.slice(0, 4).map((c, i) => (
                <div key={c.categoryId} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-muted-foreground truncate max-w-[120px]">{c.name}</span>
                  </div>
                  <span className="font-medium text-foreground">{c.postCount}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-card border border-border rounded-xl p-6" data-testid="section-recent-activity">
          <div className="flex items-center gap-2 mb-5">
            <Clock className="w-4 h-4 text-primary" />
            <h3 className="font-bold text-foreground text-sm">Recent Activity</h3>
          </div>
          <div className="space-y-3">
            {overview?.recentActivity.map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-sm" data-testid={`activity-${i}`}>
                <div className="w-2 h-2 rounded-full bg-primary shrink-0" />
                <p className="text-foreground/80 flex-1">{item.message}</p>
                <span className="text-xs text-muted-foreground shrink-0">
                  {new Date(item.time).toLocaleDateString()}
                </span>
              </div>
            ))}
            {(!overview?.recentActivity || overview.recentActivity.length === 0) && (
              <p className="text-sm text-muted-foreground">No recent activity.</p>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
