import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, FileText, PlusCircle, Tag, Image, MessageSquare, Mail,
  Search, Settings, LogOut, Rss, Sun, Moon, ExternalLink, ChevronLeft, Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/lib/theme";
import { useGetAdminMe, getGetAdminMeQueryKey, useAdminLogout } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const NAV_SECTIONS = [
  {
    label: "Content",
    items: [
      { href: "/admin/dashboard", icon: LayoutDashboard, label: "Dashboard" },
      { href: "/admin/posts", icon: FileText, label: "Posts" },
      { href: "/admin/posts/new", icon: PlusCircle, label: "Create New Post" },
      { href: "/admin/categories", icon: Tag, label: "Categories" },
    ],
  },
  {
    label: "Media & Engagement",
    items: [
      { href: "/admin/media", icon: Image, label: "Media Library" },
      { href: "/admin/comments", icon: MessageSquare, label: "Comments" },
      { href: "/admin/newsletter", icon: Mail, label: "Newsletter" },
    ],
  },
  {
    label: "Configuration",
    items: [
      { href: "/admin/seo", icon: Search, label: "SEO Settings" },
      { href: "/admin/settings", icon: Settings, label: "Site Settings" },
    ],
  },
];

export function AdminGuard({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const token = localStorage.getItem("admin_token");
  const { data: me, isLoading, isError } = useGetAdminMe({
    query: {
      enabled: !!token,
      queryKey: getGetAdminMeQueryKey(),
      retry: false,
    },
  } as Parameters<typeof useGetAdminMe>[0]);

  useEffect(() => {
    if (!token || (!isLoading && (isError || !me))) {
      setLocation("/admin/login");
    }
  }, [token, isLoading, isError, me, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-7 h-7 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Verifying session...</p>
        </div>
      </div>
    );
  }
  if (!me) return null;
  return <>{children}</>;
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const logout = useAdminLogout();
  const queryClient = useQueryClient();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        localStorage.removeItem("admin_token");
        queryClient.clear();
        setLocation("/admin/login");
      },
    });
  };

  const isActive = (href: string) => {
    if (href === "/admin/dashboard") return location === "/admin/dashboard" || location === "/admin";
    return location === href || location.startsWith(href + "/");
  };

  const Sidebar = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center shrink-0">
              <Rss className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground leading-none">InsightSphere</p>
              <p className="text-xs text-muted-foreground">Admin Panel</p>
            </div>
          </div>
        </Link>
        <button className="lg:hidden text-muted-foreground hover:text-foreground" onClick={() => setSidebarOpen(false)}>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-5">
        {NAV_SECTIONS.map((section) => (
          <div key={section.label}>
            <p className="text-xs font-semibold text-muted-foreground/60 uppercase tracking-widest px-3 mb-1.5">
              {section.label}
            </p>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                return (
                  <Link key={item.href} href={item.href}>
                    <div
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                        active
                          ? "bg-primary text-white shadow-sm"
                          : "text-muted-foreground hover:bg-muted hover:text-foreground"
                      }`}
                      onClick={() => setSidebarOpen(false)}
                      data-testid={`admin-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer actions */}
      <div className="p-3 border-t border-border space-y-0.5">
        <Link href="/">
          <div className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer transition-colors">
            <ExternalLink className="w-4 h-4" />
            <span>View Site</span>
          </div>
        </Link>
        <button
          onClick={toggleTheme}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          data-testid="admin-toggle-theme"
        >
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          <span>{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>
        </button>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
          data-testid="button-admin-logout"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );

  return (
    <AdminGuard>
      <div className="min-h-screen bg-background flex" data-testid="admin-layout">
        {/* Desktop sidebar */}
        <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r border-border bg-card fixed top-0 bottom-0 left-0 z-30">
          <Sidebar />
        </aside>

        {/* Mobile sidebar overlay */}
        {sidebarOpen && (
          <div className="lg:hidden fixed inset-0 z-40 flex">
            <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
            <aside className="relative w-64 bg-card border-r border-border flex flex-col z-50">
              <Sidebar />
            </aside>
          </div>
        )}

        {/* Main content */}
        <div className="flex-1 lg:ml-56 min-h-screen flex flex-col">
          {/* Mobile top bar */}
          <div className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-card sticky top-0 z-20">
            <button onClick={() => setSidebarOpen(true)} className="text-muted-foreground">
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-primary rounded flex items-center justify-center">
                <Rss className="w-3 h-3 text-white" />
              </div>
              <span className="text-sm font-bold text-foreground">InsightSphere Admin</span>
            </div>
          </div>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </AdminGuard>
  );
}
