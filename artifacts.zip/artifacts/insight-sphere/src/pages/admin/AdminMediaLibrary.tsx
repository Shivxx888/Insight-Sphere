import { useState, useEffect, useRef } from "react";
import { Upload, Trash2, Copy, Image, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "./AdminLayout";
import { adminFetch } from "@/lib/adminFetch";

interface MediaFile {
  filename: string;
  url: string;
  size: number;
  createdAt: string;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export default function AdminMediaLibrary() {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const data = await adminFetch<{ files: MediaFile[] }>("/api/admin/media");
      setFiles(data.files);
    } catch {
      toast({ title: "Failed to load media", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchFiles(); }, []);

  const handleUpload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({ title: "Only image files are allowed", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const token = localStorage.getItem("admin_token");
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: fd,
      });
      if (!res.ok) throw new Error("Upload failed");
      const result = await res.json() as { url: string; originalKB: number; outputKB: number };
      toast({
        title: "Image uploaded!",
        description: `Compressed from ${result.originalKB}KB → ${result.outputKB}KB`,
      });
      fetchFiles();
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (filename: string) => {
    if (!confirm(`Delete "${filename}"? This cannot be undone.`)) return;
    setDeleting(filename);
    try {
      await adminFetch(`/api/admin/media/${encodeURIComponent(filename)}`, { method: "DELETE" });
      setFiles((prev) => prev.filter((f) => f.filename !== filename));
      if (selected === filename) setSelected(null);
      toast({ title: "File deleted" });
    } catch {
      toast({ title: "Failed to delete file", variant: "destructive" });
    } finally {
      setDeleting(null);
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    toast({ title: "URL copied to clipboard!" });
  };

  const totalSize = files.reduce((sum, f) => sum + f.size, 0);

  return (
    <AdminLayout>
      <div className="p-6 max-w-7xl" data-testid="page-admin-media">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Media Library</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {files.length} file{files.length !== 1 ? "s" : ""} · {formatBytes(totalSize)} total
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2" onClick={fetchFiles} disabled={loading}>
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Button
              className="gap-2"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
            >
              {uploading ? (
                <><div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> Uploading...</>
              ) : (
                <><Upload className="w-4 h-4" /> Upload Image</>
              )}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload(f); e.target.value = ""; }}
            />
          </div>
        </div>

        {/* Drop zone */}
        <div
          className="border-2 border-dashed border-border rounded-xl p-6 text-center mb-8 hover:border-primary/50 hover:bg-muted/20 transition-all cursor-pointer"
          onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) handleUpload(f); }}
          onDragOver={(e) => e.preventDefault()}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">
            <span className="text-primary font-medium">Click to upload</span> or drag & drop images here
          </p>
          <p className="text-xs text-muted-foreground/60 mt-1">PNG, JPG, WebP — auto-converted to WebP and compressed</p>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {[...Array(10)].map((_, i) => <Skeleton key={i} className="aspect-square rounded-xl" />)}
          </div>
        ) : files.length === 0 ? (
          <div className="text-center py-20">
            <Image className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
            <p className="text-muted-foreground">No media files yet. Upload your first image above.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {files.map((file) => (
              <div
                key={file.filename}
                className={`group relative rounded-xl border overflow-hidden cursor-pointer bg-muted transition-all hover:shadow-md ${
                  selected === file.filename ? "border-primary ring-2 ring-primary/30" : "border-border"
                }`}
                onClick={() => setSelected(selected === file.filename ? null : file.filename)}
                data-testid={`media-file-${file.filename}`}
              >
                <div className="aspect-square bg-muted">
                  <img
                    src={file.url}
                    alt={file.filename}
                    className="w-full h-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="p-2">
                  <p className="text-xs font-medium text-foreground truncate">{file.filename}</p>
                  <p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p>
                </div>
                {/* Actions overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    className="w-8 h-8 bg-white rounded-lg flex items-center justify-center hover:bg-gray-100 transition-colors"
                    onClick={(e) => { e.stopPropagation(); copyUrl(file.url); }}
                    title="Copy URL"
                  >
                    <Copy className="w-3.5 h-3.5 text-gray-700" />
                  </button>
                  <button
                    className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center hover:bg-red-600 transition-colors"
                    onClick={(e) => { e.stopPropagation(); handleDelete(file.filename); }}
                    disabled={deleting === file.filename}
                    title="Delete"
                  >
                    {deleting === file.filename
                      ? <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      : <Trash2 className="w-3.5 h-3.5 text-white" />
                    }
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Selected file details */}
        {selected && (() => {
          const f = files.find((x) => x.filename === selected);
          if (!f) return null;
          return (
            <div className="mt-8 p-5 bg-card border border-border rounded-xl">
              <h3 className="font-semibold text-foreground mb-3">Selected File</h3>
              <div className="flex gap-6 items-start">
                <img src={f.url} alt={f.filename} className="w-24 h-24 object-cover rounded-lg border border-border" />
                <div className="flex-1 space-y-2 text-sm">
                  <div><span className="text-muted-foreground">File:</span> <span className="font-medium">{f.filename}</span></div>
                  <div><span className="text-muted-foreground">Size:</span> <span className="font-medium">{formatBytes(f.size)}</span></div>
                  <div><span className="text-muted-foreground">Uploaded:</span> <span className="font-medium">{new Date(f.createdAt).toLocaleDateString()}</span></div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">URL:</span>
                    <code className="text-xs bg-muted px-2 py-1 rounded flex-1 truncate">{f.url}</code>
                    <Button size="sm" variant="outline" className="gap-1 shrink-0" onClick={() => copyUrl(f.url)}>
                      <Copy className="w-3 h-3" /> Copy
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </AdminLayout>
  );
}
