import { Mail, UserCheck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import AdminLayout from "./AdminLayout";
import { useListSubscribers } from "@workspace/api-client-react";

export default function AdminNewsletter() {
  const { data: subscribers, isLoading } = useListSubscribers();

  return (
    <AdminLayout>
      <div className="p-8" data-testid="page-admin-newsletter">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Newsletter</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage your subscriber list</p>
          </div>
          <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-2">
            <UserCheck className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">{subscribers?.length ?? 0} Subscribers</span>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm" data-testid="subscribers-table">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Email</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden md:table-cell">Name</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Subscribed</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody>
              {isLoading
                ? [...Array(5)].map((_, i) => (
                    <tr key={i} className="border-b border-border last:border-0">
                      <td className="px-5 py-4"><Skeleton className="h-4 w-48" /></td>
                      <td className="px-4 py-4 hidden md:table-cell"><Skeleton className="h-4 w-24" /></td>
                      <td className="px-4 py-4 hidden lg:table-cell"><Skeleton className="h-4 w-28" /></td>
                      <td className="px-4 py-4"><Skeleton className="h-4 w-16" /></td>
                    </tr>
                  ))
                : subscribers?.map((sub) => (
                    <tr key={sub.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors" data-testid={`subscriber-row-${sub.id}`}>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                            {sub.email[0]?.toUpperCase()}
                          </div>
                          <span className="font-medium text-foreground">{sub.email}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 hidden md:table-cell">
                        <span className="text-muted-foreground">{sub.name ?? "—"}</span>
                      </td>
                      <td className="px-4 py-4 hidden lg:table-cell">
                        <span className="text-muted-foreground text-xs">
                          {new Date(sub.subscribedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant={sub.active ? "default" : "outline"} className="text-xs">
                          {sub.active ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
            </tbody>
          </table>

          {subscribers?.length === 0 && (
            <div className="text-center py-16">
              <Mail className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">No subscribers yet.</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Share your newsletter signup to grow your list.</p>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
