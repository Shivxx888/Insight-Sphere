import { useState } from "react";
import { Link } from "wouter";
import { Plus, Edit, Trash2, Eye, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import AdminLayout from "./AdminLayout";
import { useListPosts, useDeletePost, useListCategories, useListAuthors } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function AdminPosts() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useListPosts({ page, limit: 15 }, { query: { queryKey: ["admin-posts", page] } });
  const deletePost = useDeletePost();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = (slug: string, title: string) => {
    if (!confirm(`Delete "${title}"?`)) return;
    deletePost.mutate({ slug }, {
      onSuccess: () => {
        toast({ title: "Post deleted" });
        queryClient.invalidateQueries({ queryKey: ["admin-posts"] });
      },
    });
  };

  return (
    <AdminLayout>
      <div className="p-8" data-testid="page-admin-posts">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Posts</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage your blog articles</p>
          </div>
          <Link href="/admin/posts/new">
            <Button className="gap-2" data-testid="button-new-post">
              <Plus className="w-4 h-4" /> New Post
            </Button>
          </Link>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm" data-testid="posts-table">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Title</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden md:table-cell">Category</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Status</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Views</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i} className="border-b border-border last:border-0">
                      <td className="px-5 py-4"><Skeleton className="h-4 w-48" /></td>
                      <td className="px-4 py-4 hidden md:table-cell"><Skeleton className="h-4 w-24" /></td>
                      <td className="px-4 py-4 hidden lg:table-cell"><Skeleton className="h-4 w-16" /></td>
                      <td className="px-4 py-4 hidden lg:table-cell"><Skeleton className="h-4 w-12" /></td>
                      <td className="px-5 py-4"><Skeleton className="h-4 w-20 ml-auto" /></td>
                    </tr>
                  ))
                : data?.posts.map((post) => (
                    <tr key={post.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors" data-testid={`post-row-${post.id}`}>
                      <td className="px-5 py-4">
                        <div className="flex items-start gap-3">
                          <FileText className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div>
                            <p className="font-medium text-foreground line-clamp-1">{post.title}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">{post.slug}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 hidden md:table-cell">
                        <span className="text-xs text-muted-foreground">{post.category.name}</span>
                      </td>
                      <td className="px-4 py-4 hidden lg:table-cell">
                        <Badge variant={post.status === "published" ? "default" : "outline"} className="text-xs">
                          {post.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 hidden lg:table-cell">
                        <span className="text-xs text-muted-foreground">{post.viewCount}</span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <Link href={`/blog/${post.slug}`}>
                            <Button variant="ghost" size="icon" className="w-7 h-7" data-testid={`button-view-${post.id}`}>
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                          </Link>
                          <Link href={`/admin/posts/${post.slug}/edit`}>
                            <Button variant="ghost" size="icon" className="w-7 h-7" data-testid={`button-edit-${post.id}`}>
                              <Edit className="w-3.5 h-3.5" />
                            </Button>
                          </Link>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-7 h-7 text-destructive hover:text-destructive"
                            onClick={() => handleDelete(post.slug, post.title)}
                            data-testid={`button-delete-${post.id}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>

        {data && data.totalPages > 1 && (
          <div className="flex items-center justify-between mt-5">
            <p className="text-sm text-muted-foreground">
              Showing {(page - 1) * 15 + 1}–{Math.min(page * 15, data.total)} of {data.total} posts
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage((p) => p - 1)} disabled={page === 1} data-testid="button-prev-page">Previous</Button>
              <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={page === data.totalPages} data-testid="button-next-page">Next</Button>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
