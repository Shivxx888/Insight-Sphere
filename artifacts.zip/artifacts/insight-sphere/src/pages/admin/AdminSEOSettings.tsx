import { useState, useEffect } from "react";
import { Save, RefreshCw, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "./AdminLayout";
import { adminFetch } from "@/lib/adminFetch";

interface SEOSettings {
  metaTitleSuffix: string;
  metaDescription: string;
  googleAnalyticsId: string;
  adsensePublisherId: string;
  googleSiteVerification: string;
  twitterHandle: string;
  ogImage: string;
}

const DEFAULTS: SEOSettings = {
  metaTitleSuffix: " | InsightSphere",
  metaDescription: "Learn Something New Every Day — AI, Technology, Finance, Business & More",
  googleAnalyticsId: "",
  adsensePublisherId: "",
  googleSiteVerification: "",
  twitterHandle: "@InsightSphere",
  ogImage: "https://insightsphere.replit.app/og-image.png",
};

export default function AdminSEOSettings() {
  const [settings, setSettings] = useState<SEOSettings>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    adminFetch<SEOSettings>("/api/admin/seo-settings")
      .then((data) => setSettings(data))
      .catch(() => toast({ title: "Failed to load SEO settings", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await adminFetch("/api/admin/seo-settings", { method: "PUT", body: JSON.stringify(settings) });
      toast({ title: "SEO settings saved!", description: "Changes will take effect on next deployment." });
    } catch {
      toast({ title: "Failed to save settings", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const field = (key: keyof SEOSettings, label: string, placeholder: string, hint?: string, multiline = false) => (
    <div>
      <label className="text-sm font-medium text-foreground mb-1.5 block">{label}</label>
      {multiline ? (
        <Textarea
          value={settings[key]}
          onChange={(e) => setSettings((p) => ({ ...p, [key]: e.target.value }))}
          placeholder={placeholder}
          rows={3}
        />
      ) : (
        <Input
          value={settings[key]}
          onChange={(e) => setSettings((p) => ({ ...p, [key]: e.target.value }))}
          placeholder={placeholder}
        />
      )}
      {hint && <p className="text-xs text-muted-foreground mt-1">{hint}</p>}
    </div>
  );

  return (
    <AdminLayout>
      <div className="p-6 max-w-3xl" data-testid="page-admin-seo">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">SEO Settings</h1>
            <p className="text-muted-foreground text-sm mt-1">Configure site-wide SEO, analytics, and social settings</p>
          </div>
          <Button onClick={save} disabled={saving} className="gap-2">
            {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
          </div>
        ) : (
          <div className="space-y-6">
            {/* Meta */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Meta Tags</h3>
              {field("metaTitleSuffix", "Title Suffix", " | InsightSphere", "Appended to every page title. E.g. \" | InsightSphere\"")}
              {field("metaDescription", "Default Meta Description", "Your site description...", "Used when a page has no custom description.", true)}
              {field("ogImage", "Default OG Image URL", "https://insightsphere.replit.app/og-image.png", "Used in social sharing previews when no article image is set.")}
              {field("twitterHandle", "Twitter/X Handle", "@InsightSphere", "Used in Twitter Card meta tags.")}
            </div>

            {/* Analytics */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Google Analytics 4</h3>
                <a href="https://analytics.google.com" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1">
                  Open GA4 <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              {field("googleAnalyticsId", "Measurement ID", "G-XXXXXXXXXX", "Set VITE_GA_MEASUREMENT_ID in environment secrets to activate analytics tracking.")}
            </div>

            {/* AdSense */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Google AdSense</h3>
                <a href="https://adsense.google.com" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1">
                  Open AdSense <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              {field("adsensePublisherId", "Publisher ID", "ca-pub-XXXXXXXXXXXXXXXX", "Set VITE_ADSENSE_PUBLISHER_ID in environment secrets to show real ads. Current placeholder slots will auto-activate.")}
            </div>

            {/* Search Console */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Google Search Console</h3>
                <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1">
                  Open GSC <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              {field("googleSiteVerification", "Verification Code", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", 'Paste the verification code from the HTML meta tag method. Then add it to the <meta name="google-site-verification"> in index.html.')}
            </div>

            {/* Sitemap info */}
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5">
              <h3 className="font-semibold text-foreground text-sm mb-2">🔗 SEO Endpoints</h3>
              <div className="space-y-1 text-xs text-muted-foreground font-mono">
                <p>Dynamic Sitemap: <a href="/api/sitemap.xml" target="_blank" className="text-primary hover:underline">/api/sitemap.xml</a></p>
                <p>RSS Feed: <a href="/api/feed.xml" target="_blank" className="text-primary hover:underline">/api/feed.xml</a></p>
                <p>Robots.txt: <a href="/robots.txt" target="_blank" className="text-primary hover:underline">/robots.txt</a></p>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
