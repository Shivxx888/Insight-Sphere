import { useState, useEffect } from "react";
import { Save, RefreshCw, Globe, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "./AdminLayout";
import { adminFetch } from "@/lib/adminFetch";

interface SiteSettings {
  siteName: string;
  tagline: string;
  adminEmail: string;
  postsPerPage: number;
  featuredPostsCount: number;
  commentsEnabled: boolean;
  newsletterEnabled: boolean;
  maintenanceMode: boolean;
  footerText: string;
}

const DEFAULTS: SiteSettings = {
  siteName: "InsightSphere",
  tagline: "Learn Something New Every Day",
  adminEmail: "shivxx888@gmail.com",
  postsPerPage: 9,
  featuredPostsCount: 3,
  commentsEnabled: true,
  newsletterEnabled: true,
  maintenanceMode: false,
  footerText: "Learn Something New Every Day",
};

export default function AdminSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    adminFetch<SiteSettings>("/api/admin/site-settings")
      .then((data) => setSettings(data))
      .catch(() => toast({ title: "Failed to load site settings", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await adminFetch("/api/admin/site-settings", { method: "PUT", body: JSON.stringify(settings) });
      toast({ title: "Site settings saved!" });
    } catch {
      toast({ title: "Failed to save settings", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const set = <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) =>
    setSettings((p) => ({ ...p, [key]: value }));

  const Toggle = ({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) => (
    <div className="flex items-center justify-between py-3 border-b border-border last:border-0">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${checked ? "bg-primary" : "bg-muted"}`}
        aria-checked={checked}
        role="switch"
      >
        <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${checked ? "translate-x-5" : "translate-x-0"}`} />
      </button>
    </div>
  );

  return (
    <AdminLayout>
      <div className="p-6 max-w-3xl" data-testid="page-admin-settings">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Site Settings</h1>
            <p className="text-muted-foreground text-sm mt-1">General configuration for your blog</p>
          </div>
          <Button onClick={save} disabled={saving} className="gap-2">
            {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
          </div>
        ) : (
          <div className="space-y-6">
            {/* Branding */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <div className="flex items-center gap-2 mb-1">
                <Globe className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Branding</h3>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Site Name</label>
                <Input value={settings.siteName} onChange={(e) => set("siteName", e.target.value)} placeholder="InsightSphere" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Tagline</label>
                <Input value={settings.tagline} onChange={(e) => set("tagline", e.target.value)} placeholder="Learn Something New Every Day" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Footer Text</label>
                <Input value={settings.footerText} onChange={(e) => set("footerText", e.target.value)} placeholder="Learn Something New Every Day" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Admin Email</label>
                <Input type="email" value={settings.adminEmail} onChange={(e) => set("adminEmail", e.target.value)} placeholder="admin@example.com" />
              </div>
            </div>

            {/* Blog Configuration */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-5">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Blog Configuration</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Posts Per Page</label>
                  <Input
                    type="number"
                    min={1}
                    max={50}
                    value={settings.postsPerPage}
                    onChange={(e) => set("postsPerPage", Number(e.target.value))}
                  />
                  <p className="text-xs text-muted-foreground mt-1">Articles shown per page on /blog</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Featured Posts</label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={settings.featuredPostsCount}
                    onChange={(e) => set("featuredPostsCount", Number(e.target.value))}
                  />
                  <p className="text-xs text-muted-foreground mt-1">Max posts shown in hero section</p>
                </div>
              </div>
            </div>

            {/* Feature Toggles */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider mb-4">Features</h3>
              <Toggle
                label="Comments"
                desc="Allow readers to post comments on articles"
                checked={settings.commentsEnabled}
                onChange={(v) => set("commentsEnabled", v)}
              />
              <Toggle
                label="Newsletter"
                desc="Show newsletter subscription form across the site"
                checked={settings.newsletterEnabled}
                onChange={(v) => set("newsletterEnabled", v)}
              />
            </div>

            {/* Maintenance Mode */}
            <div className={`border rounded-xl p-6 ${settings.maintenanceMode ? "bg-amber-50 dark:bg-amber-900/20 border-amber-300 dark:border-amber-700" : "bg-card border-border"}`}>
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className={`w-4 h-4 ${settings.maintenanceMode ? "text-amber-500" : "text-muted-foreground"}`} />
                <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Maintenance Mode</h3>
              </div>
              <p className="text-xs text-muted-foreground mb-4">When enabled, the public site shows a maintenance message. Admin panel remains accessible.</p>
              <Toggle
                label={settings.maintenanceMode ? "⚠️ Maintenance Mode is ON" : "Maintenance Mode"}
                desc={settings.maintenanceMode ? "Public site is currently showing a maintenance page." : "Turn this on to put the site in maintenance mode."}
                checked={settings.maintenanceMode}
                onChange={(v) => set("maintenanceMode", v)}
              />
            </div>

            {/* Password Change Note */}
            <div className="bg-muted/50 border border-border rounded-xl p-5">
              <h3 className="font-semibold text-foreground text-sm mb-2">🔐 Admin Password</h3>
              <p className="text-xs text-muted-foreground">
                To change the admin password, set the <code className="bg-muted px-1 py-0.5 rounded">ADMIN_PASSWORD_HASH</code> environment secret
                to a new bcrypt hash (rounds=12). Generate it with: <code className="bg-muted px-1 py-0.5 rounded">node -e "const b = require('bcryptjs'); console.log(b.hashSync('NewPassword', 12))"</code>
              </p>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
