import { useState, useEffect, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, Save, Upload, Image, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import AdminLayout from "./AdminLayout";
import {
  useCreatePost,
  useUpdatePost,
  useGetPost,
  getGetPostQueryKey,
  useListCategories,
  useListAuthors,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function PostEditor() {
  const [, setLocation] = useLocation();
  const [, editParams] = useRoute("/admin/posts/:slug/edit");
  const isEdit = !!editParams?.slug;
  const slug = editParams?.slug ?? "";

  const { data: existingPost } = useGetPost(slug, {
    query: { enabled: isEdit, queryKey: getGetPostQueryKey(slug) },
  });
  const { data: categories } = useListCategories();
  const { data: authors } = useListAuthors();
  const createPost = useCreatePost();
  const updatePost = useUpdatePost();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    categoryId: 1,
    authorId: 1,
    coverImage: "",
    tags: "",
    status: "draft" as "draft" | "published",
    featured: false,
    metaTitle: "",
    metaDescription: "",
  });
  const [uploading, setUploading] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [charCount, setCharCount] = useState(0);

  useEffect(() => {
    if (existingPost) {
      setForm({
        title: existingPost.title,
        slug: existingPost.slug,
        excerpt: existingPost.excerpt,
        content: existingPost.content,
        categoryId: existingPost.category.id,
        authorId: existingPost.author.id,
        coverImage: existingPost.coverImage,
        tags: existingPost.tags.join(", "),
        status: existingPost.status as "draft" | "published",
        featured: existingPost.featured ?? false,
        metaTitle: existingPost.metaTitle ?? "",
        metaDescription: existingPost.metaDescription ?? "",
      });
      setCharCount(existingPost.content.length);
    } else if (authors && authors.length > 0) {
      setForm((prev) => ({ ...prev, authorId: authors[0].id }));
    }
  }, [existingPost, authors]);

  useEffect(() => {
    if (categories && categories.length > 0 && !isEdit) {
      setForm((prev) => ({ ...prev, categoryId: categories[0].id }));
    }
  }, [categories, isEdit]);

  const autoSlug = (title: string) =>
    title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .slice(0, 60);

  const handleImageUpload = async (file: File) => {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json() as { url: string };
      setForm((prev) => ({ ...prev, coverImage: url }));
      toast({ title: "Image uploaded!", description: "Cover image set successfully." });
    } catch {
      toast({ title: "Upload failed", description: "Please try again or paste an image URL.", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageUpload(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file?.type.startsWith("image/")) handleImageUpload(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      ...form,
      tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
      coverImage: form.coverImage || `https://picsum.photos/seed/${form.slug}/1200/600`,
      metaTitle: form.metaTitle || undefined,
      metaDescription: form.metaDescription || undefined,
    };

    if (isEdit) {
      updatePost.mutate({ slug, data }, {
        onSuccess: () => {
          toast({ title: "Post updated!" });
          queryClient.invalidateQueries({ queryKey: ["admin-posts"] });
          setLocation("/admin/posts");
        },
        onError: () => toast({ title: "Error updating post", variant: "destructive" }),
      });
    } else {
      createPost.mutate(
        { data: { ...data, categoryId: Number(data.categoryId), authorId: Number(data.authorId) } },
        {
          onSuccess: () => {
            toast({ title: "Post created!" });
            queryClient.invalidateQueries({ queryKey: ["admin-posts"] });
            setLocation("/admin/posts");
          },
          onError: () => toast({ title: "Error creating post", variant: "destructive" }),
        }
      );
    }
  };

  const wordCount = form.content.split(/\s+/).filter(Boolean).length;
  const readingTime = Math.ceil(wordCount / 200) || 1;

  return (
    <AdminLayout>
      <div className="p-6 max-w-5xl" data-testid="page-post-editor">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/admin/posts")} data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground">{isEdit ? "Edit Post" : "New Post"}</h1>
            <p className="text-muted-foreground text-sm">{isEdit ? `Editing: ${slug}` : "Create a new article"}</p>
          </div>
          <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground bg-muted rounded-lg px-3 py-1.5">
            <span>{wordCount} words</span>
            <span>·</span>
            <span>~{readingTime} min read</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content (left/center) */}
          <div className="lg:col-span-2 space-y-5">
            {/* Content Card */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Content</h3>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Title *</label>
                <Input
                  value={form.title}
                  onChange={(e) => {
                    const t = e.target.value;
                    setForm((prev) => ({ ...prev, title: t, slug: isEdit ? prev.slug : autoSlug(t) }));
                  }}
                  placeholder="Enter your article title..."
                  required
                  className="text-base"
                  data-testid="input-post-title"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                  Slug * <span className="text-primary cursor-pointer ml-1" onClick={() => setForm((p) => ({ ...p, slug: autoSlug(p.title) }))}>← auto-generate</span>
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground shrink-0">/blog/</span>
                  <Input
                    value={form.slug}
                    onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))}
                    placeholder="url-friendly-slug"
                    required
                    data-testid="input-post-slug"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Excerpt * <span className="text-muted-foreground/60">(shown in listings & SEO)</span></label>
                <Textarea
                  value={form.excerpt}
                  onChange={(e) => setForm((p) => ({ ...p, excerpt: e.target.value }))}
                  placeholder="Brief compelling description of the article (150–200 characters ideal)..."
                  rows={2}
                  required
                  data-testid="textarea-post-excerpt"
                />
                <p className="text-xs text-muted-foreground mt-1">{form.excerpt.length}/200 chars</p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-muted-foreground">
                    Content * <span className="text-muted-foreground/60">(Markdown supported)</span>
                  </label>
                </div>
                <div className="text-xs text-muted-foreground mb-2 bg-muted rounded-lg px-3 py-1.5 inline-block">
                  ## Heading&nbsp;&nbsp;### Subheading&nbsp;&nbsp;**bold**&nbsp;&nbsp;*italic*&nbsp;&nbsp;- list&nbsp;&nbsp;`code`&nbsp;&nbsp;&gt; quote
                </div>
                <Textarea
                  value={form.content}
                  onChange={(e) => { setForm((p) => ({ ...p, content: e.target.value })); setCharCount(e.target.value.length); }}
                  placeholder={`## Introduction\n\nStart writing your article here...\n\n## Section 1\n\nYour content...\n\n## Conclusion\n\nWrap up your article.`}
                  rows={20}
                  required
                  className="font-mono text-sm"
                  data-testid="textarea-post-content"
                />
                <p className="text-xs text-muted-foreground mt-1">{wordCount} words · ~{readingTime} min read</p>
              </div>
            </div>

            {/* SEO Card */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">SEO</h3>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                  Meta Title <span className="text-muted-foreground/60">(defaults to article title)</span>
                </label>
                <Input
                  value={form.metaTitle}
                  onChange={(e) => setForm((p) => ({ ...p, metaTitle: e.target.value }))}
                  placeholder="SEO-optimized title (50–60 chars ideal)"
                  data-testid="input-meta-title"
                />
                <p className="text-xs text-muted-foreground mt-1">{form.metaTitle.length}/60 chars</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                  Meta Description <span className="text-muted-foreground/60">(defaults to excerpt)</span>
                </label>
                <Textarea
                  value={form.metaDescription}
                  onChange={(e) => setForm((p) => ({ ...p, metaDescription: e.target.value }))}
                  placeholder="SEO description (150–160 chars ideal)"
                  rows={2}
                  data-testid="textarea-meta-description"
                />
                <p className="text-xs text-muted-foreground mt-1">{form.metaDescription.length}/160 chars</p>
              </div>
            </div>
          </div>

          {/* Sidebar Settings (right) */}
          <div className="space-y-5">
            {/* Publish Card */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Publish</h3>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Status</label>
                <select
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={form.status}
                  onChange={(e) => setForm((p) => ({ ...p, status: e.target.value as "draft" | "published" }))}
                  data-testid="select-post-status"
                >
                  <option value="draft">📝 Draft</option>
                  <option value="published">✅ Published</option>
                </select>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.featured}
                  onChange={(e) => setForm((p) => ({ ...p, featured: e.target.checked }))}
                  className="rounded"
                  data-testid="checkbox-featured"
                />
                <span className="text-sm text-foreground">⭐ Featured post</span>
              </label>
              <div className="flex flex-col gap-2 pt-2 border-t border-border">
                <Button
                  type="submit"
                  disabled={createPost.isPending || updatePost.isPending}
                  className="w-full gap-2"
                  data-testid="button-save-post"
                >
                  <Save className="w-4 h-4" />
                  {(createPost.isPending || updatePost.isPending) ? "Saving..." : isEdit ? "Update Post" : "Publish Post"}
                </Button>
                <Button type="button" variant="outline" className="w-full" onClick={() => setLocation("/admin/posts")}>
                  Cancel
                </Button>
              </div>
            </div>

            {/* Category & Author Card */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Settings</h3>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Category *</label>
                <select
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={form.categoryId}
                  onChange={(e) => setForm((p) => ({ ...p, categoryId: Number(e.target.value) }))}
                  data-testid="select-post-category"
                >
                  {categories?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Author *</label>
                <select
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={form.authorId}
                  onChange={(e) => setForm((p) => ({ ...p, authorId: Number(e.target.value) }))}
                  data-testid="select-post-author"
                >
                  {authors?.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Tags</label>
                <Input
                  value={form.tags}
                  onChange={(e) => setForm((p) => ({ ...p, tags: e.target.value }))}
                  placeholder="AI, technology, finance"
                  data-testid="input-post-tags"
                />
                <p className="text-xs text-muted-foreground mt-1">Comma-separated</p>
              </div>
            </div>

            {/* Cover Image Card */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold text-foreground text-sm uppercase tracking-wider">Cover Image</h3>

              {form.coverImage && (
                <div className="relative rounded-lg overflow-hidden aspect-video bg-muted">
                  <img src={form.coverImage} alt="Cover" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setForm((p) => ({ ...p, coverImage: "" }))}
                    className="absolute top-2 right-2 w-6 h-6 bg-black/60 text-white rounded-full flex items-center justify-center hover:bg-black/80 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              {/* Upload area */}
              <div
                className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-primary/50 hover:bg-muted/30 transition-all"
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                  data-testid="input-image-upload"
                />
                {uploading ? (
                  <div className="flex flex-col items-center gap-2 py-2">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs text-muted-foreground">Uploading...</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 py-2">
                    <Upload className="w-6 h-6 text-muted-foreground" />
                    <p className="text-xs text-muted-foreground">
                      <span className="text-primary font-medium">Click to upload</span> or drag & drop
                    </p>
                    <p className="text-xs text-muted-foreground/60">PNG, JPG, WebP up to 5MB</p>
                  </div>
                )}
              </div>

              <div>
                <p className="text-xs text-muted-foreground mb-1.5">Or paste an image URL:</p>
                <Input
                  value={form.coverImage}
                  onChange={(e) => setForm((p) => ({ ...p, coverImage: e.target.value }))}
                  placeholder="https://example.com/image.jpg"
                  data-testid="input-post-cover"
                />
              </div>
            </div>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
}
