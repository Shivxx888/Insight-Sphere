import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Search, Home, BookOpen, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Layout from "@/components/Layout";

export default function NotFound() {
  const [query, setQuery] = useState("");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    document.title = "404 — Page Not Found | InsightSphere";
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      window.location.href = `/blog?q=${encodeURIComponent(query)}`;
    }
  };

  return (
    <Layout>
      <div className="min-h-[70vh] flex items-center justify-center px-4" data-testid="page-404">
        <div
          className="max-w-xl w-full text-center"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.5s ease, transform 0.5s ease",
          }}
        >
          {/* 404 Visual */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="text-8xl font-black text-primary/20 select-none leading-none">4</div>
            <div className="w-24 h-24 bg-gradient-to-br from-primary via-primary/80 to-primary/60 rounded-3xl flex items-center justify-center shadow-lg">
              <span className="text-3xl font-black text-white">IS</span>
            </div>
            <div className="text-8xl font-black text-primary/20 select-none leading-none">4</div>
          </div>

          {/* Message */}
          <div className="flex items-center justify-center gap-2 text-amber-500 mb-3">
            <AlertTriangle className="w-5 h-5" />
            <span className="text-sm font-semibold uppercase tracking-wider">Page Not Found</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Oops! This page doesn't exist.
          </h1>
          <p className="text-muted-foreground text-lg mb-10 leading-relaxed">
            The article or page you're looking for may have been moved, renamed, or deleted.
            Let's get you back on track.
          </p>

          {/* Search */}
          <form onSubmit={handleSearch} className="flex gap-2 mb-8 max-w-md mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search articles..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-9"
                data-testid="input-404-search"
              />
            </div>
            <Button type="submit">Search</Button>
          </form>

          {/* Quick Links */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link href="/">
              <Button variant="outline" className="gap-2" data-testid="link-404-home">
                <Home className="w-4 h-4" />
                Go Home
              </Button>
            </Link>
            <Link href="/blog">
              <Button variant="outline" className="gap-2" data-testid="link-404-blog">
                <BookOpen className="w-4 h-4" />
                Browse Articles
              </Button>
            </Link>
            <Button variant="ghost" className="gap-2" onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4" />
              Go Back
            </Button>
          </div>

          {/* Popular categories */}
          <div className="mt-12 pt-8 border-t border-border">
            <p className="text-sm text-muted-foreground mb-4 font-medium">Explore Popular Topics</p>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {[
                { label: "🤖 AI", href: "/categories/artificial-intelligence" },
                { label: "💻 Technology", href: "/categories/technology" },
                { label: "💰 Finance", href: "/categories/finance" },
                { label: "📣 Marketing", href: "/categories/digital-marketing" },
                { label: "🔒 Cybersecurity", href: "/categories/cybersecurity" },
                { label: "🔧 How-To Guides", href: "/categories/how-to-guides" },
              ].map((cat) => (
                <Link key={cat.href} href={cat.href}>
                  <Button variant="secondary" size="sm" className="text-xs">
                    {cat.label}
                  </Button>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
