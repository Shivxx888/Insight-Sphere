import { pgTable, text, serial, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const authorsTable = pgTable("authors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  bio: text("bio").notNull().default(""),
  avatar: text("avatar").notNull().default(""),
  role: text("role").notNull().default("Author"),
  postCount: integer("post_count").notNull().default(0),
  social: jsonb("social").notNull().default({}),
});

export const insertAuthorSchema = createInsertSchema(authorsTable).omit({ id: true });
export type InsertAuthor = z.infer<typeof insertAuthorSchema>;
export type Author = typeof authorsTable.$inferSelect;
