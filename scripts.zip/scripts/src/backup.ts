import { db, postsTable, authorsTable, categoriesTable, commentsTable, subscribersTable, contactsTable } from "@workspace/db";
import fs from "fs";
import path from "path";

const BACKUP_DIR = path.join(process.cwd(), "..", "backups");

async function backup() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const filename = path.join(BACKUP_DIR, `backup-${timestamp}.json`);

  console.log(`Creating backup: ${filename}`);

  const [posts, authors, categories, comments, newsletter, contacts] = await Promise.all([
    db.select().from(postsTable),
    db.select().from(authorsTable),
    db.select().from(categoriesTable),
    db.select().from(commentsTable),
    db.select().from(subscribersTable),
    db.select().from(contactsTable),
  ]);

  const backup = {
    createdAt: new Date().toISOString(),
    version: "1.0",
    tables: {
      posts: { count: posts.length, data: posts },
      authors: { count: authors.length, data: authors },
      categories: { count: categories.length, data: categories },
      comments: { count: comments.length, data: comments },
      newsletter: { count: newsletter.length, data: newsletter }, 
      contacts: { count: contacts.length, data: contacts },
    },
  };

  fs.writeFileSync(filename, JSON.stringify(backup, null, 2), "utf-8");

  const stats = fs.statSync(filename);
  const sizeMB = (stats.size / 1024 / 1024).toFixed(2);

  console.log(`✅ Backup complete!`);
  console.log(`   File: ${filename}`);
  console.log(`   Size: ${sizeMB} MB`);
  console.log(`   Posts: ${posts.length} | Authors: ${authors.length} | Categories: ${categories.length}`);
  console.log(`   Comments: ${comments.length} | Newsletter: ${newsletter.length} | Contacts: ${contacts.length}`);

  cleanOldBackups();
  process.exit(0);
}

function cleanOldBackups(keepLast = 10) {
  if (!fs.existsSync(BACKUP_DIR)) return;
  const files = fs.readdirSync(BACKUP_DIR)
    .filter((f) => f.startsWith("backup-") && f.endsWith(".json"))
    .sort()
    .reverse();

  const toDelete = files.slice(keepLast);
  for (const file of toDelete) {
    fs.unlinkSync(path.join(BACKUP_DIR, file));
    console.log(`   Deleted old backup: ${file}`);
  }
}

backup().catch((e) => { console.error(e); process.exit(1); });
