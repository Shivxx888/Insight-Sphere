import { db, categoriesTable, authorsTable, postsTable, sql, eq } from "@workspace/db";

async function fixCounts() {
  const categories = await db.select().from(categoriesTable);
  for (const cat of categories) {
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(postsTable)
      .where(eq(postsTable.categoryId, cat.id));
    await db.update(categoriesTable).set({ postCount: count }).where(eq(categoriesTable.id, cat.id));
    console.log(`${cat.name}: ${count} posts`);
  }

  const authors = await db.select().from(authorsTable);
  for (const author of authors) {
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(postsTable)
      .where(eq(postsTable.authorId, author.id));
    await db.update(authorsTable).set({ postCount: count }).where(eq(authorsTable.id, author.id));
    console.log(`Author ${author.name}: ${count} posts`);
  }

  console.log("Done!");
  process.exit(0);
}

fixCounts().catch((e) => { console.error(e); process.exit(1); });
