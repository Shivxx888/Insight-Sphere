import { db, postsTable, commentsTable, authorsTable, categoriesTable } from "@workspace/db";

async function reset() {
  console.log("Deleting all comments...");
  await db.delete(commentsTable);

  console.log("Deleting all posts...");
  await db.delete(postsTable);

  console.log("Deleting all authors...");
  await db.delete(authorsTable);

  console.log("Inserting Shivam as the sole author...");
  await db.insert(authorsTable).values({
    name: "Shivam",
    email: "shivxx888@gmail.com",
    bio: "Founder and editor of InsightSphere. Passionate about AI, technology, personal finance, and digital entrepreneurship. Dedicated to helping curious minds learn something new every day.",
    avatar: "",
    role: "Founder & Editor",
    postCount: 0,
    social: { twitter: "InsightSphere", linkedin: "insightsphere" },
  });

  console.log("Resetting all category post counts to 0...");
  await db.update(categoriesTable).set({ postCount: 0 });

  console.log("Done! Database reset complete. Shivam is the only author.");
  process.exit(0);
}

reset().catch((e) => { console.error(e); process.exit(1); });
