import { db, categoriesTable, authorsTable, postsTable, commentsTable } from "@workspace/db";

const categories = [
  { name: "Artificial Intelligence", slug: "artificial-intelligence", description: "Deep dives into AI, machine learning, and the future of intelligent systems.", color: "#6366F1", icon: "Brain", postCount: 0 },
  { name: "Technology", slug: "technology", description: "The latest in tech: gadgets, software, and innovations shaping tomorrow.", color: "#3B82F6", icon: "Cpu", postCount: 0 },
  { name: "Finance", slug: "finance", description: "Personal finance, investing, and economic insights for the modern age.", color: "#10B981", icon: "TrendingUp", postCount: 0 },
  { name: "Make Money Online", slug: "make-money-online", description: "Proven strategies, side hustles, and digital income streams.", color: "#F59E0B", icon: "DollarSign", postCount: 0 },
  { name: "Business", slug: "business", description: "Strategy, entrepreneurship, and the future of work.", color: "#EF4444", icon: "Briefcase", postCount: 0 },
  { name: "Education", slug: "education", description: "Learning strategies, online courses, and lifelong skill-building.", color: "#8B5CF6", icon: "GraduationCap", postCount: 0 },
  { name: "Digital Marketing", slug: "digital-marketing", description: "SEO, content, social media, and growth hacking strategies.", color: "#EC4899", icon: "Megaphone", postCount: 0 },
  { name: "Cybersecurity", slug: "cybersecurity", description: "Protecting data, privacy, and digital assets in a connected world.", color: "#14B8A6", icon: "Shield", postCount: 0 },
  { name: "Mobile Apps", slug: "mobile-apps", description: "App development trends, reviews, and mobile-first strategies.", color: "#F97316", icon: "Smartphone", postCount: 0 },
  { name: "How-To Guides", slug: "how-to-guides", description: "Practical step-by-step guides for navigating digital life.", color: "#06B6D4", icon: "BookOpen", postCount: 0 },
];

const authors = [
  {
    name: "Shivam",
    email: "shivxx888@gmail.com",
    bio: "Founder and editor of InsightSphere. Passionate about AI, technology, personal finance, and digital entrepreneurship. Helping curious minds learn something new every day.",
    avatar: "",
    role: "Founder & Editor",
    postCount: 0,
    social: { twitter: "InsightSphere", linkedin: "insightsphere" },
  },
];

async function seed() {
  console.log("Seeding categories...");
  for (const cat of categories) {
    await db.insert(categoriesTable).values(cat).onConflictDoNothing();
  }
  console.log(`Seeded ${categories.length} categories.`);

  console.log("Seeding author...");
  for (const author of authors) {
    await db.insert(authorsTable).values(author).onConflictDoNothing();
  }
  console.log(`Seeded ${authors.length} author(s).`);

  console.log("Seed complete! Use the Admin Panel to add your blog posts.");
  process.exit(0);
}

seed().catch((e) => { console.error(e); process.exit(1); });
